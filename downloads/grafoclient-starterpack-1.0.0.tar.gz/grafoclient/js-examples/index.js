'use strict';

var GrafoClient = require('grafo-client/lib/grafo_client');

var Concept = require('grafo-client/lib/models/concept');
var Attribute = require('grafo-client/lib/models/attribute');
var Link = require('grafo-client/lib/models/relationship');

var ColorPalette = require('grafo-client/lib/models/color_palette');
var DataTypes = require('grafo-client/lib/models/datatypes');

var config = require('./conf.js')

var sample = async function() {
    try {
        console.log("Starting Grafo Client Example");
        var grafoClient = new GrafoClient();
        console.log("Authenticating to Grafo Server with the provided config : ");
        console.log(config);
        await grafoClient.init(config);
        console.log("Authenticated");

        //this is how you would get a document. the document is parsed into a simple structure 
        // which is easy to simple and also equally fast to look up
        //getEkgDocument(grafoClient, '19c2e5ce-8589-466a-bc2c-00661931badf');

        var ekgDoc = await createEkgDoc(grafoClient);

        await doConceptCrudOps(grafoClient, ekgDoc);

        //await deleteEkgDoc(grafoClient, ekgDoc);

        console.log("closing connection... ");
        console.log("session is still somehow open and the shell looks as if it is up and running.");
        console.log("this is a known defect. we are working on it earnestly");
        console.log("Ctrl + C to kill the session");

        await grafoClient.close();

    } catch(err) {
        console.log(err);
    }
};

var getEkgDocument = async function(grafoClient, docId) {
    var ekgDoc = await grafoClient.getEkgDocument(docId);
    console.log(ekgDoc);
};

var createEkgDoc = async function(grafoClient) {
    var d = new Date();
    var docName = 'TestDoc_' + d.getMilliseconds()
    console.log("Creating a Ekg Document with name " +  docName + " in default location ... ");
    var ekgDoc = await grafoClient.createEkgDocument('', docName);
    console.log(ekgDoc);
    return ekgDoc;
};

var doConceptCrudOps = async function(grafoClient, ekgDoc) {
    console.log("Adding concepts to doc ...");
    var conceptCreated01 = await ekgDoc.addConcept("Concept - ABC", 700, 90);
    var conceptCreated02 = await ekgDoc.addConcept("Concept - DEF", 600, 100);
    console.log("Two concepts added");


    console.log("Cloning Concept for Update ....");
    var clonedConceptForUpdate = await ekgDoc.cloneConcept(conceptCreated01.getId());
    console.log(clonedConceptForUpdate);
    clonedConceptForUpdate.setDescription("Updating 123");
    clonedConceptForUpdate.setLabel("Hello");
    clonedConceptForUpdate.setIri({iri:"check", hasEdited:"true"});

    console.log("Updating EKG with modified (pre-cloned) Concept ....");
    var updatedConcept = await ekgDoc.updateConcept(clonedConceptForUpdate);
    console.log("Concept updated");
    console.log(updatedConcept);

    console.log("Deleting Concept ....");
    await ekgDoc.deleteConcept(conceptCreated02.getId());
    console.log("Concept Deleted");
};

var deleteEkgDoc = async function(grafoClient, ekgDoc) {
    console.log("Deleting Document....");
    await grafoClient.deleteDocument(ekgDoc.getId());
};

sample();
