'use strict';

var GrafoClient = require('grafo-client/lib/grafo_client');

var DocSearchCriteria = require('grafo-client/lib/models/resource_search_criteria');

var config = require('./conf/conf.js');
var moment = require('moment');

this.execute = async function() {
    console.log("Starting Grafo Client Shared Documents Example");
    var grafoClient = new GrafoClient();
    console.log("Authenticating to Grafo Server with the provided config : ");
    await grafoClient.init(config);
    console.log("Authenticated");

    var today = moment(new Date()).format("YYYY-MM-DD");
    //list Folders without Parent
    console.log("Listing Shared Documents At Top Level");
    //ResourceSearchCriteria(limit, page, parent, deleted)
    //Shared Documents can be listed by providing date ranges such as createdOn(date), createdBefore(date),
    //createdAfter(date), createdOnOrBefore(date), createdOnOrAfter(date),
    //createdBetween(startDate, endDate, inclType), createdBetween(startDate, endDate)
    var docSearchCriteria1 = new DocSearchCriteria().setLimit(5).setPage(1).setDeleted(false).createdBefore(today);
    var allDocsWithoutParent = await grafoClient.getSharedDocumentsWithMe(docSearchCriteria1);
    console.log("allDocsWithoutParent**********");
    console.log(allDocsWithoutParent);

    // list all Documents
    console.log("List All Shared Documents");
    var page = 1;
    var docSearchCriteria3 = new DocSearchCriteria().setLimit(2).setPage(page).setDeleted(false).createdBefore(today);
    var documentList = await grafoClient.getSharedDocumentsWithMe(docSearchCriteria3);
    while(documentList.length > 0) {
        documentList = await grafoClient.getSharedDocumentsWithMe(docSearchCriteria3.setPage(page).createdBefore(today));
        if(documentList.length > 0)
            console.log(documentList);

        page++;
    }

    //*****************************************************************

    //Get Document By Id
    if(allDocsWithoutParent.length > 0) {
        console.log("Get Document By Id");
        //getMyDocumentById(documentId)
        var fetchedDocumentById = await grafoClient.getSharedDocumentWithMe(allDocsWithoutParent[0].id);
        console.log("Get Shared Document by Id*******");
        console.log(fetchedDocumentById);
    }
    //*****************************************************************

    console.log("closing connection... ");
    await grafoClient.close();
};

module.exports = {
  execute: this.execute
};