const expect = require('chai').expect;

const allInOneExamples = require('../99_All_In_One_Examples');

describe('Grafo-Client All Examples', function() {
    it('Execute All', async function() {
        try {
            await allInOneExamples.executeAll();
            expect(true).to.eql(true);
        }
        catch (err) {
            console.log(err);
            expect(true).to.eql(false);
        }
    });
});
