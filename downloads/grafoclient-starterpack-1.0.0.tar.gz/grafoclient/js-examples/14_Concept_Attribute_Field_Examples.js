'use strict';

var GrafoClient = require('grafo-client/lib/grafo_client');
var Document = require('grafo-client/lib/models/document');

var config = require('./conf/conf.js');

this.execute = async function() {
    console.log("Starting Grafo Client Concept Attribute Field CRUD Example");
    var grafoClient = new GrafoClient();
    console.log("Authenticating to Grafo Server with the provided config : ");
    console.log(config);
    await grafoClient.init(config);
    console.log("Authenticated");

    //Creating new ekg Document and Add concept to it
    var ekgDoc = await createEmptyEkgDoc(grafoClient);

    var concept = await addConcept(ekgDoc);

    var attributeGroup = await addAttributeToConcept(ekgDoc, concept);

    var attribute = attributeGroup.attributeList[0];

    await doConceptAttributeFieldCrudOps(ekgDoc, concept, attribute);

    await deleteEkgDocument(grafoClient, ekgDoc.id);

    console.log("closing connection");
    await grafoClient.close();
};

var createEmptyEkgDoc = async function(grafoClient) {
    var d = new Date();
    var document1 = new Document(); document1.setTitle('TestDoc_' + d.getTime());
    console.log("Creating Document with name " +  document1.getTitle() + " in default location ... ");
    var docDetails =  await grafoClient.createDocument(document1);
    var ekgDoc = await grafoClient.createEkgDocument(docDetails);
    console.log("Created Empty EKG Document with Id " + ekgDoc.id);
    return ekgDoc;
};

var addConcept = async function(ekgDoc) {
    console.log("Adding concept to doc ...");
    var createdConcept = await ekgDoc.addConcept("TestA");
    return createdConcept;
};

var addAttributeToConcept = async function(ekgDoc, concept) {
    var createdConceptAttr = await ekgDoc.addAttributeToConcept("attr1", "attr to add field",null,
                                null, null, null, "attrIri", null, concept.id);
    return createdConceptAttr;
};

var doConceptAttributeFieldCrudOps = async  function(ekgDoc, concept, attribute) {
    /*
        ADDING CONCEPT ATTRIBUTE FIELDS
        Parameters to addConceptAttributeField method in order are listed below
        Title, Text, ConceptId, AttributeId
     */
    console.log(attribute);
    console.log("Adding concept Attribute Fields to Concept Attribute ...");
    var conceptAttributeFieldCreated01 = await ekgDoc.addConceptAttributeField("field1", "field text1",
                                                        concept.id, attribute.id);
    var conceptAttributeFieldCreated02 = await ekgDoc.addConceptAttributeField("field2", "",
                                                        concept.id, attribute.id);
    var conceptAttributeFieldCreated03 = await ekgDoc.addConceptAttributeField("field3", "field text 3",
                                                        concept.id, attribute.id);
    console.log("3 concept Attribute Fields added");

    /*
        LISTING ALL CONCEPT ATTRIBUTE FIELDS IN THE CONCEPT ATTRIBUTE
     */
    console.log("Listing all the concept Attribute fields in the concept attribute........");
    var conceptAttributeFieldList = await ekgDoc.getConceptAttributeFields(concept.id, attribute.id);
    console.log(conceptAttributeFieldList);

    /*
        FETCHING ONE CONCEPT ATTRIBUTE FIELD
     */
    var conceptAttrFields = await ekgDoc.getConceptAttributeFields(concept.id, attribute.id);
    var fieldId = conceptAttrFields[1].id;
    console.log("Fetching Concept Attribute Field with id "+fieldId);
    var fetchedConceptAttributeField = await ekgDoc.getConceptAttributeField(concept.id, attribute.id, fieldId);
    console.log(fetchedConceptAttributeField);

    /*
        UPDATING CONCEPT ATTRIBUTE FIELD
        Parameters to updateConceptAttributeField method in order are listed below
        Title, Text, FieldId, ConceptId, attributeId
     */
    var fieldIdToUpdate = conceptAttrFields[0].id;
    console.log("Updating Concept Attribute Field with id "+fieldIdToUpdate);
    var updatedConceptAttributeField = await ekgDoc.updateConceptAttributeField("updated Field", "",
        fieldIdToUpdate, concept.id, attribute.id);
    console.log("Updated Concept Attribute Fields");
    console.log(await ekgDoc.getConceptAttributeFields(concept.id, attribute.id));

    /*
        DELETING CONCEPT ATTRIBUTE FIELD
     */
    var conceptAttributeFields = await ekgDoc.getConceptAttributeFields(concept.id, attribute.id);
    var fieldIdToDelete = conceptAttributeFields[2].id;
    console.log("Deleting Concept Attribute Field with id "+fieldIdToDelete);
    await ekgDoc.deleteConceptAttributeField(concept.id, attribute.id, fieldIdToDelete);
    console.log("Concept Attribute Field Deleted");

};


var deleteEkgDocument = async function(grafoClient, ekgDocId) {
    console.log("Deleting Document....");
    await grafoClient.deleteEkgDocument(ekgDocId);
};

module.exports = {
    execute: this.execute
};