'use strict';

var GrafoClient = require('grafo-client/lib/grafo_client');
var Document = require('grafo-client/lib/models/document');

var config = require('./conf/conf.js');

this.execute = async function() {
    console.log("Starting Grafo Client Concept Field CRUD Example");
    var grafoClient = new GrafoClient();
    console.log("Authenticating to Grafo Server with the provided config : ");
    console.log(config);
    await grafoClient.init(config);
    console.log("Authenticated");

    //Creating new ekg Document and Add concept to it
    var ekgDoc = await createEmptyEkgDoc(grafoClient);

    var concept = await addConcept(ekgDoc);

    await doConceptFieldCrudOps(ekgDoc, concept);

    await deleteEkgDocument(grafoClient, ekgDoc.id);

    console.log("closing connection");
    await grafoClient.close();
};

var createEmptyEkgDoc = async function(grafoClient) {
    var d = new Date();
    var document1 = new Document(); document1.setTitle('TestDoc_' + d.getTime());
    console.log("Creating Document with name " +  document1.getTitle() + " in default location ... ");
    var docDetails =  await grafoClient.createDocument(document1);
    var ekgDoc = await grafoClient.createEkgDocument(docDetails);
    console.log("Created Empty EKG Document with Id " + ekgDoc.id);
    return ekgDoc;
};

var addConcept = async function(ekgDoc) {
    console.log("Adding concept to doc ...");
    var createdConcept = await ekgDoc.addConcept("TestA");
    return createdConcept;
};

var doConceptFieldCrudOps = async  function(ekgDoc, concept) {
    /*
        ADDING CONCEPT FIELDS
        Parameters to addConceptField method in order are listed below
        Title, Text, ConceptId
     */
    console.log("Adding concept Fields to Concept ...");
    var conceptFieldCreated01 = await ekgDoc.addConceptField("field1", "field text1", concept.id);
    var conceptFieldCreated02 = await ekgDoc.addConceptField("field2", "", concept.id);
    var conceptFieldCreated03 = await ekgDoc.addConceptField("field3", "field text 3", concept.id);
    console.log("3 concept Fields added");

    /*
        LISTING ALL CONCEPT FIELDS IN THE CONCEPT
     */
    console.log("Listing all the concept fields in the concept........");
    var conceptFieldList = await ekgDoc.getConceptFields(concept.id);
    console.log(conceptFieldList);

    /*
        FETCHING ONE CONCEPT FIELD
     */
    var fieldId = ekgDoc.getConceptFields(concept.id)[1].id;
    console.log("Fetching Concept Field with id "+fieldId);
    var fetchedConceptField = ekgDoc.getConceptField(concept.id, fieldId);
    console.log(fetchedConceptField);

    /*
        UPDATING CONCEPT FIELD
        Parameters to updateConceptField method in order are listed below
        Title, Text, FieldId, ConceptId
     */
    var fieldIdToUpdate = await ekgDoc.getConceptFields(concept.id)[0].id;
    console.log("Updating Concept Field with id "+fieldIdToUpdate);
    var updatedConceptField = await ekgDoc.updateConceptField("updated Field", "",
                                            fieldIdToUpdate, concept.id);
    console.log(updatedConceptField);

    /*
        DELETING CONCEPT FIELD
     */
    var fieldIdToDelete = await ekgDoc.getConceptFields(concept.id)[2].id;
    console.log("Deleting Concept Field with id "+fieldIdToDelete);
    await ekgDoc.deleteConceptField(concept.id, fieldIdToDelete);
    console.log("Concept Field Deleted");

};


var deleteEkgDocument = async function(grafoClient, ekgDocId) {
    console.log("Deleting Document....");
    await grafoClient.deleteEkgDocument(ekgDocId);
};

module.exports = {
    execute: this.execute
};