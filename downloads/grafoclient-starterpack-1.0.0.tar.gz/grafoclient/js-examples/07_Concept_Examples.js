'use strict';

var GrafoClient = require('grafo-client/lib/grafo_client');
var Document = require('grafo-client/lib/models/document');

var ColorPalette = require('grafo-client/lib/models/color_palette');

var config = require('./conf/conf.js');

this.execute = async function() {
    console.log("Starting Grafo Client Concept CRUD Example");
    var grafoClient = new GrafoClient();
    console.log("Authenticating to Grafo Server with the provided config");
    await grafoClient.init(config);
    console.log("Authenticated");

    var ekgDoc = await createEmptyEkgDoc(grafoClient);

    await doConceptCrudOps(grafoClient, ekgDoc);

    await deleteEkgDocument(grafoClient, ekgDoc.id);

    console.log("closing connection");
    await grafoClient.close();
};

var createEmptyEkgDoc = async function(grafoClient) {
    var d = new Date();
    var document1 = new Document(); document1.setTitle('TestDoc_' + d.getTime());
    console.log("Creating Document with name " +  document1.getTitle() + " in default location ... ");
    var docDetails =  await grafoClient.createDocument(document1);
    var ekgDoc = await grafoClient.createEkgDocument(docDetails);
    console.log("Created Empty EKG Document with Id " + ekgDoc.id);
    return ekgDoc;
};

var doConceptCrudOps = async function(grafoClient, ekgDoc) {
    /*
        ADDING CONCEPTS
        Parameters to addConcept method in order are listed below
        Label, PositionX, PositionY, Description, Color, Fields, Iri
     */
    console.log("Adding concepts to doc ...");
    var conceptCreated01 = await ekgDoc.addConcept("TestA");
    var conceptCreated02 = await ekgDoc.addConcept("TestB", 600, 100);
    var conceptCreated03 = await ekgDoc.addConcept("TestC", null, null, null, ColorPalette.color.STEEL_BLUE);
    var conceptCreated04 = await ekgDoc.addConcept("TestD", 200, 10, "Test Description", null, [{"Hello":"World"}]);
    var conceptCreated05 = await ekgDoc.addConcept("TestE", null, null, null, null, null, "www.abc.com/schema/con5");
    console.log("Five concepts added");


    /*
        UPDATING CONCEPTS
         Parameters to updateConcept method in order are listed below
        Label, PositionX, PositionY, Description, Color, Fields, Mapping, Iri, Id
     */
    console.log("Updating Concept ....");
    var updatedConcept01 = await ekgDoc.updateConcept("Hello", null, null, "Updating Concept A",
        null, null, null, null, conceptCreated02.getId());
    var updatedConcept02 = await ekgDoc.updateConcept("", null, null, null,
        ColorPalette.color.CORAL_RED, null, null, "www.abc.com/con2", conceptCreated03.getId());
    var updatedConcept03 = await ekgDoc.updateConcept(null, null, null, null,
        ColorPalette.color.DAFFODIL_YELLOW, null, null, null, conceptCreated04.getId());
    console.log("Three Concepts updated");

    /*
        DELETING CONCEPT
     */
    console.log("Deleting Concept ....");
    await ekgDoc.deleteConcept(conceptCreated01.getId());
    console.log("Concept Deleted");

    /*
        LISTING ALL CONCEPT IN THE DOCUMENT
     */
    console.log("Listing all the concepts in the document........");
    var conceptList = await ekgDoc.getConcepts();
    console.log(conceptList);

    /*
        FETCHING ONE CONCEPT
     */

    console.log("Fetching Concept");
    var fetchedConcept = ekgDoc.getConcept(conceptCreated05.getId());
    console.log(fetchedConcept.toObject());
};


var deleteEkgDocument = async function(grafoClient, ekgDocId) {
    console.log("Deleting Document....");
    await grafoClient.deleteEkgDocument(ekgDocId);
};

module.exports = {
    execute: this.execute
};