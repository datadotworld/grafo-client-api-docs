'use strict';

var GrafoClient = require('grafo-client/lib/grafo_client');
var config = require('./conf/conf.js');
var ReplySearchCriteria = require('grafo-client/lib/models/reply_search_criteria');
var moment = require('moment');

this.execute = async function() {
    try {
        console.log("Starting Grafo Client Example");
        var grafoClient = new GrafoClient();
        console.log("Authenticating to Grafo Server with the provided config : ");
        console.log(config);
        await grafoClient.init(config);
        console.log("Authenticated");

        await getRelationshipCommentReplies(grafoClient);

        console.log("closing connection");
        await grafoClient.close();
    } catch (err) {
        console.log(err);
    }
};
/* To run this example
 set DocId, RelationshipId and CommentId to your existing docId, relationshipId and
 conversationId of relationship's comments */
var getRelationshipCommentReplies = async function(grafoClient) {
    var replySearchCriteria = new ReplySearchCriteria()
        .setDocId("6fa870a0-e568-44d9-b425-2681744f8172")
        .setRelationshipId("link-860f72a4-2015-4f58-b6cf-dde0d653b5cc")
        .setCommentId("c42bb8c2-bbcf-4ab0-be07-5e5dc848d344")
        .createdOnOrBefore(moment.now());
    var allReplies = await grafoClient.getReplies(replySearchCriteria);
    console.log(allReplies);
};

exports.execute();

module.exports = {
    execute: this.execute
};