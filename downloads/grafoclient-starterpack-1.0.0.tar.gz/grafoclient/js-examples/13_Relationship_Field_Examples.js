'use strict';

var GrafoClient = require('grafo-client/lib/grafo_client');
var Document = require('grafo-client/lib/models/document');

var config = require('./conf/conf.js');

this.execute = async function() {
    console.log("Starting Grafo Client Relationship Field CRUD Example");
    var grafoClient = new GrafoClient();
    console.log("Authenticating to Grafo Server with the provided config : ");
    console.log(config);
    await grafoClient.init(config);
    console.log("Authenticated");

    //Creating new ekg Document and Add concept to it
    var ekgDoc = await createEmptyEkgDoc(grafoClient);

    await addConcepts(ekgDoc);

    var relationship = await addRelationship(ekgDoc);

    await doRelationshipFieldCrudOps(ekgDoc, relationship);

    await deleteEkgDocument(grafoClient, ekgDoc.id);

    console.log("closing connection");
    await grafoClient.close();
};

var createEmptyEkgDoc = async function(grafoClient) {
    var d = new Date();
    var document1 = new Document(); document1.setTitle('TestDoc_' + d.getTime());
    console.log("Creating Document with name " +  document1.getTitle() + " in default location ... ");
    var docDetails =  await grafoClient.createDocument(document1);
    var ekgDoc = await grafoClient.createEkgDocument(docDetails);
    console.log("Created Empty EKG Document with Id " + ekgDoc.id);
    return ekgDoc;
};

var addConcepts = async function(ekgDoc) {
    console.log("Adding Concept to doc ...");
    await ekgDoc.addConcept("FromConcept");
    await ekgDoc.addConcept("ToConcept");
};

var addRelationship = async function(ekgDoc) {
    console.log("Adding Relationship to doc ...");
    var concepts = await ekgDoc.getConcepts();
    var fromConceptId = concepts[0].id;
    var toConceptId = concepts[1].id;
    var relationship = await ekgDoc.addRelationship("Relation1", fromConceptId, toConceptId);
    return relationship;
};

var doRelationshipFieldCrudOps = async  function(ekgDoc, relationship) {
    /*
        ADDING RELATIONSHIP FIELDS
        Parameters to addRelationshipField method in order are listed below
        Title, Text, RelationshipId
     */
    console.log("Adding Relationship Fields to Relationship ...");
    var relationshipFieldCreated01 = await ekgDoc.addRelationshipField("field1", "field text1", relationship.id);
    var relationshipFieldCreated02 = await ekgDoc.addRelationshipField("field2", "", relationship.id);
    var relationshipFieldCreated03 = await ekgDoc.addRelationshipField("field3", "field text 3", relationship.id);
    console.log("3 Relationship Fields added");

    /*
        LISTING ALL RELATIONSHIP FIELDS IN THE RELATIONSHIP
     */
    console.log("Listing all the Relationship fields in the Relationship........");
    var relationshipFieldList = await ekgDoc.getRelationshipFields(relationship.id);
    console.log(relationshipFieldList);

    /*
        FETCHING ONE RELATIONSHIP FIELD
     */
    var fieldId = await ekgDoc.getRelationshipFields(relationship.id)[1].id;
    console.log("Fetching Relationship Field with id "+fieldId);
    var fetchedRelationshipField = ekgDoc.getRelationshipField(relationship.id, fieldId);
    console.log(fetchedRelationshipField);

    /*
        UPDATING RELATIONSHIP FIELD
        Parameters to updateRelationshipField method in order are listed below
        Title, Text, FieldId, RelationshipId
     */
    var fieldIdToUpdate = await ekgDoc.getRelationshipFields(relationship.id)[0].id;
    console.log("Updating Relationship Field with id "+fieldIdToUpdate);
    var updatedRelationshipField = await ekgDoc.updateRelationshipField("updated Field", "updated Text",
        fieldIdToUpdate, relationship.id);
    console.log(updatedRelationshipField);

    /*
        DELETING RELATIONSHIP FIELD
     */
    var fieldIdToDelete = await ekgDoc.getRelationshipFields(relationship.id)[2].id;
    console.log("Deleting Relationship Field with id "+fieldIdToDelete);
    await ekgDoc.deleteRelationshipField(relationship.id, fieldIdToDelete);
    console.log("Relationship Field Deleted");

};

var deleteEkgDocument = async function(grafoClient, ekgDocId) {
    console.log("Deleting Document....");
    await grafoClient.deleteEkgDocument(ekgDocId);
};

module.exports = {
    execute: this.execute
};