'use strict';

var GrafoClient = require('grafo-client/lib/grafo_client');

var config = require('./conf/conf.js');
var Document = require('grafo-client/lib/models/document');
var DocumentShare = require('grafo-client/lib/models/document_share');
var DocPermissions = require('grafo-client/lib/models/document_permissions');


this.execute = async function() {
    console.log("Starting Grafo Client Example");
    var grafoClient = new GrafoClient();
    console.log("Authenticating to Grafo Server with the provided config");
    await grafoClient.init(config);
    console.log("Authenticated");

    var docCreated = await createDocument(grafoClient);
    var docShared = await createDocumentShare(grafoClient, docCreated.getId());
    await getDocumentShares(grafoClient, docShared[0].getDocumentId());
    await getDocumentShare(grafoClient, docShared[0].getDocumentId(), docShared[0].getId());
    await updateDocumentShare(grafoClient, docShared[0].getDocumentId(), docShared[0].getId());
    await deleteDocumentShare(grafoClient, docShared[0].getDocumentId(), docShared[0].getId());


    console.log("closing connection");
    await grafoClient.close();
};

var createDocument = async function(grafoClient) {
    var doc = new Document();
    doc.setTitle('Document for sharing');
    var docCreated = await grafoClient.createDocument(doc);
    console.log(docCreated);
    return docCreated;
};

var getDocumentShares = async function(grafoClient, docId) {
    var docShareList = await grafoClient.getDocumentShares(docId);
    console.log("List Shared doc");
    console.log(docShareList);
};

var getDocumentShare = async function(grafoClient, docId, id) {
    var docShare = await grafoClient.getDocumentShare(docId, id);
    console.log("Get Shared doc");
    console.log(docShare);
};

var createDocumentShare = async function(grafoClient, docId) {
    var docShare = new DocumentShare();
    docShare.setSharedWithEmail('testcapsenta2@gmail.com');
    docShare.setPermissions(DocPermissions.getDocumentPermissions().VIEW)
    var docShareList = await grafoClient.createDocumentShare(docId, docShare);
    console.log("Shared Doc");
    console.log(docShareList);
    return docShareList;
};

var updateDocumentShare = async function(grafoClient, docId, id) {
    var docShare = await grafoClient.getDocumentShare(docId, id);
    docShare.setPermissions(DocPermissions.getDocumentPermissions().COMMENT)
    var docShareList = await grafoClient.updateDocumentShare(docShare);
    console.log("Update Shared Doc");
    console.log(docShareList);
};

var deleteDocumentShare = async function(grafoClient, docId, id) {
    var docShareResp = await grafoClient.deleteDocumentShare(docId, id);
    console.log(docShareResp);
    console.log("Delete Shared Doc");
};

module.exports = {
    execute: this.execute
};
