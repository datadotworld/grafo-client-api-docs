'use strict';

var GrafoClient = require('grafo-client/lib/grafo_client');
var config = require('./conf/conf.js');
var CommentSearchCriteria = require('grafo-client/lib/models/comment_search_criteria');
var moment = require('moment');

this.execute = async function() {
    try {
        console.log("Starting Grafo Client Example");
        var grafoClient = new GrafoClient();
        console.log("Authenticating to Grafo Server with the provided config : ");
        console.log(config);
        await grafoClient.init(config);
        console.log("Authenticated");

        await getRelationshipAttributeComments(grafoClient);

        console.log("closing connection");
        await grafoClient.close();
    } catch (err) {
        console.log(err);
    }
};
/* To run this example
 set DocId, RelationshipId and attributeId to your existing docId, relationshipId and
 attributeId having comments */
var getRelationshipAttributeComments = async function(grafoClient) {
    var commSearchCriteria = new CommentSearchCriteria()
        .setDocId("6fa870a0-e568-44d9-b425-2681744f8172")
        .setRelationshipId("link-860f72a4-2015-4f58-b6cf-dde0d653b5cc")
        .setAttributeId("linkattr-0f47614f-d0d7-401f-a275-3f9fd04ba5d3")
        .createdOnOrBefore(moment.now());
    var allComments = await grafoClient.getComments(commSearchCriteria);
    console.log(allComments);
};

exports.execute();

module.exports = {
    execute: this.execute
};