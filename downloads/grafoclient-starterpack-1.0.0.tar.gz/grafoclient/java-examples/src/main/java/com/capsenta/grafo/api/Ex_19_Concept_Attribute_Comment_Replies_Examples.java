package com.capsenta.grafo.api;

import java.time.LocalDateTime;
import java.util.Iterator;

import com.capsenta.grafo.GrafoClient;
import com.capsenta.grafo.entity.comment.Reply;
import com.capsenta.grafo.entity.comment.ReplySearchCriteria;

public class Ex_19_Concept_Attribute_Comment_Replies_Examples {

	public static void main(String[] args) {
		try {
			Ex_19_Concept_Attribute_Comment_Replies_Examples ex = new Ex_19_Concept_Attribute_Comment_Replies_Examples();
			ex.execute();		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/* To run this example
	 set DocId, ConceptId, attributeId and CommentId to your existing docId, conceptId,
	 attributeId and conversationId of concept attribute's comments */
	public void execute() throws Exception {
		String docId = "2f6d7b86-4a23-46c0-a20a-6fb98fef4c57";
		
		String conceptId = "node-f0850644-0f0e-4f7d-9aaf-eeb19413d934";
		
		String attributeId = "attr-f0f0bf84-a393-4964-922b-19d5c057f7b2";
		
		String commentId = "ef4ec550-509b-41e6-b0c1-40ccc21c1691";
		
		System.out.println("*************Listing Concept Attribute Comment Replies");
		listConceptAttributeCommentReplies(docId, conceptId, attributeId, commentId);
	}
	
	private void listConceptAttributeCommentReplies(String docId, String conceptId, String attributeId, String commentId) throws Exception {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		)
		{
			ReplySearchCriteria replySearch = new ReplySearchCriteria().docId(docId)
													.conceptId(conceptId)
													.attributeId(attributeId)
													.commentId(commentId).limit(5).page(1)
													.createdOnOrBefore(LocalDateTime.now());
					
			for (Iterator<Reply> replyIter = gClient.getConceptAttributeCommentReplies(replySearch); replyIter.hasNext();) {
				System.out.println(replyIter.next());
			}
		}
	}
}
