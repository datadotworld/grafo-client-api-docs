package com.capsenta.grafo.api;

public class Ex_99_All_In_One_Examples {
	
	public static void main(String[] args) {
		try {
			Ex_99_All_In_One_Examples examples = new Ex_99_All_In_One_Examples();
			examples.executeAll();			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/* This does not contain comments and comment replies examples for concept, relationship and their
	*  attributes as they are not reproducible*/
	public void executeAll() throws Exception {
		Ex_01_Folder_Examples folderEx = new Ex_01_Folder_Examples();
		folderEx.execute();
		
		Ex_02_Document_Examples docEx = new Ex_02_Document_Examples();
		docEx.execute();
		
		Ex_03_Shared_Area_Folder_Examples shareFolderEx = new Ex_03_Shared_Area_Folder_Examples();
		shareFolderEx.execute();
		
		Ex_04_Documents_Shared_With_Me_Examples sharedDocsEx = new Ex_04_Documents_Shared_With_Me_Examples();
		sharedDocsEx.execute();
		
		Ex_05_Document_Share_Examples docShareEx = new Ex_05_Document_Share_Examples();
		docShareEx.execute();
		
		Ex_06_Ekg_Document_Coarse_Grained_Example ekgDocCoarseGrainedEx = new Ex_06_Ekg_Document_Coarse_Grained_Example();
		ekgDocCoarseGrainedEx.execute();
		
		Ex_07_Concept_Examples conceptEx = new Ex_07_Concept_Examples();
		conceptEx.execute();
		
		Ex_08_Concept_Attribute_Examples conceptAttrEx = new Ex_08_Concept_Attribute_Examples();
		conceptAttrEx.execute();
		
		Ex_09_Relationship_Examples relationshipEx = new Ex_09_Relationship_Examples();
		relationshipEx.execute();
		
		Ex_10_Relationship_Attribute_Examples relationshipAttrEx = new Ex_10_Relationship_Attribute_Examples();
		relationshipAttrEx.execute();
		
		Ex_11_Specialization_Examples specializationEx = new Ex_11_Specialization_Examples();
		specializationEx.execute();
		
		Ex_12_Concept_Field_Examples conceptFieldEx = new Ex_12_Concept_Field_Examples();
		conceptFieldEx.execute();
		
		Ex_13_Relationship_Field_Examples relationshipFieldEx = new Ex_13_Relationship_Field_Examples();
		relationshipFieldEx.execute();
		
		Ex_14_Concept_Attribute_Field_Examples conceptAttrFieldEx = new Ex_14_Concept_Attribute_Field_Examples();
		conceptAttrFieldEx.execute();
		
		Ex_15_Relationship_Attribute_Field_Examples RelationshipAttrFieldEx = new Ex_15_Relationship_Attribute_Field_Examples();
		RelationshipAttrFieldEx.execute();
	}
}
