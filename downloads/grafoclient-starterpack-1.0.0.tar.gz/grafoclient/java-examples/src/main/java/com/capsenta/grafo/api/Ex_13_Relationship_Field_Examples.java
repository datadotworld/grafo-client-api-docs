package com.capsenta.grafo.api;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.capsenta.grafo.GrafoClient;
import com.capsenta.grafo.entity.GenericGrafoResponse;
import com.capsenta.grafo.entity.ekg.Concept;
import com.capsenta.grafo.entity.ekg.Field;
import com.capsenta.grafo.entity.ekg.Relationship;
import com.capsenta.grafo.entity.ekg.RelationshipType;
import com.capsenta.grafo.entity.resource.Document;

public class Ex_13_Relationship_Field_Examples {
	
	private Document document;
	
	private Relationship relationship;
	
	private List<Field> fieldList;
	
	
	public static void main(String[] args) {
		try {
			Ex_13_Relationship_Field_Examples ex = new Ex_13_Relationship_Field_Examples();
			ex.execute();		
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void execute() throws Exception {
		System.out.println("Creating Document and Adding Concepts and a Relationship");
		createDocumentAndAddTwoConceptsAndOneRelationship();
		
		System.out.println("Add Fields to Relationship");
		addFieldsToRelationships();
		
		System.out.println("List Fields in a Relationship");
		listFieldsInRelationship();
		
		System.out.println("Get Relationship Field By Id");
		getRelationshipFieldById();
		
		System.out.println("Update Relationship Field");
		updateRelationshipField();
		
		System.out.println("Delete Relationship Field");
		deleteRelationshipField();
		
		System.out.println("Delete Document");
		deleteDocument();
	}
	
	private void createDocumentAndAddTwoConceptsAndOneRelationship() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			//Create Document
			Document doc = new Document();
			doc.setTitle("My Test Doc " + System.currentTimeMillis());
			document = gClient.createDocument(doc);
			
			//Creating 2 concepts
			List<Concept> conceptList = new ArrayList<>();
			for(int i=0; i<2; i++) {
				Concept conceptForAdd = new Concept("Test " + i);
				Concept concept = gClient.createConcept(document.getId(), conceptForAdd);
				conceptList.add(concept);
			}
			
			//Create One Relationship
			Relationship relationship1 = new Relationship(conceptList.get(0), conceptList.get(1), "first link", RelationshipType.PEER);
			relationship = gClient.createRelationship(document.getId(), relationship1);
		}
	}
	
	private void addFieldsToRelationships() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			Field field1 = new Field("field1"); field1.setText("text1");
			gClient.addRelationshipField(document.getId(), relationship.getId(), field1);
			
			Field field2 = new Field("field2"); field2.setText("text2");
			gClient.addRelationshipField(document.getId(), relationship.getId(), field2);
		}
	}
	
	private void listFieldsInRelationship() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			fieldList = gClient.getRelationshipFields(document.getId(), relationship.getId());
			fieldList.forEach(field -> System.out.println(field));
		}
	}
	
	private void getRelationshipFieldById() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			Field fieldFetched = gClient.getRelationshipField(document.getId(), relationship.getId(), fieldList.get(1).getId());
			System.out.println("Field fetched from "+ relationship.getId()+" is "+ fieldFetched);
		}
	}
	
	private void updateRelationshipField() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			Field fieldToUpdate = gClient.getRelationshipField(document.getId(), relationship.getId(), fieldList.get(0).getId());			
			fieldToUpdate.setTitle("updatedField1");
			fieldToUpdate.setText("updatedText1");
			Relationship relFieldToUpdate = gClient.updateRelationshipField(document.getId(), relationship.getId(), fieldToUpdate);
			System.out.println("Updated Relationshipp Field: " + relFieldToUpdate);
		}
	}
	
	private void deleteRelationshipField() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			String fieldIdForDelete = gClient.getRelationshipField(document.getId(), relationship.getId(), fieldList.get(1).getId()).getId();
			GenericGrafoResponse response = gClient.deleteRelationshipField(document.getId(), relationship.getId(), fieldIdForDelete);
			System.out.println(response);
		}
	}
	
	private void deleteDocument() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			gClient.deleteDocument(document.getId());
		}
	}
}
