package com.capsenta.grafo.api;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.capsenta.grafo.GrafoClient;
import com.capsenta.grafo.entity.GenericGrafoResponse;
import com.capsenta.grafo.entity.ekg.CardinalityType;
import com.capsenta.grafo.entity.ekg.Color;
import com.capsenta.grafo.entity.ekg.Concept;
import com.capsenta.grafo.entity.ekg.Relationship;
import com.capsenta.grafo.entity.ekg.RelationshipType;
import com.capsenta.grafo.entity.resource.Document;

public class Ex_09_Relationship_Examples 
{
	public static void main(String[] args) {
		try {
			Ex_09_Relationship_Examples ex = new Ex_09_Relationship_Examples();
			ex.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void execute() throws Exception {
		UUID docId = createDocument();
		
		List<Concept> conceptList = createConcepts(docId);
		
		Relationship newRelationship = addRelationship(docId, conceptList);
		System.out.println(newRelationship);
		
		Relationship updatedRel = updateRelationship(docId, newRelationship);
		System.out.println(updatedRel);
		
		List<Relationship> listRelationships = listAllRelationships(docId);
		listRelationships.forEach(link -> System.out.println(link));
		
		Relationship fetchedRel = fetchRelationshipById(docId, newRelationship.getId());
		System.out.println(fetchedRel);
		
		deleteRelationship(docId, newRelationship.getId());
		
		deleteDocument(docId);
	}

	private UUID createDocument() throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		)
		{	
			System.out.println("************** Creating Document ***************** ");
			Document newDoc = new Document();
			newDoc.setTitle("My Test Doc " + System.currentTimeMillis());
			Document createdDoc = gClient.createDocument(newDoc);
			return createdDoc.getId();
		}
		
	}
	
	private List<Concept> createConcepts(UUID docId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			List<Concept> conceptList = new ArrayList<>();
			System.out.println("************** Creating Concepts ***************** ");
			for(int i=0; i<2; i++) {
				Concept concept = new Concept("Test Concept " + i);
				Concept newConcept = gClient.createConcept(docId, concept);
				conceptList.add(newConcept);
			}
			return conceptList;
		}
	}
	
	private Relationship addRelationship(UUID docId, List<Concept> conceptList) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			System.out.println("************** Adding Relationships ***************** ");
			Relationship relationship1 = new Relationship(conceptList.get(0), conceptList.get(1), "first link", RelationshipType.PEER);
			Relationship newRel = gClient.createRelationship(docId, relationship1);
			
			Relationship relationship2 = new Relationship(conceptList.get(0), conceptList.get(1), "second link", RelationshipType.PEER);
			gClient.createRelationship(docId, relationship2);
			
			Relationship relationship3 = new Relationship(conceptList.get(0), conceptList.get(1), "third link", RelationshipType.PEER);
			gClient.createRelationship(docId, relationship3);
			
			Relationship relationship4 = new Relationship(conceptList.get(0), "self link");
			gClient.createRelationship(docId, relationship4);
			
			return newRel;
		}
		
	}
	
	private Relationship updateRelationship(UUID docId, Relationship rel) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			System.out.println("************** Updating Relationship ***************** ");
			rel.setCardinalityType(CardinalityType.MIN);
			rel.setCardinality("100");
			rel.setColor(Color.BROWN);
			Relationship updatedRel = gClient.updateRelationship(docId, rel);
			return updatedRel;
		}
		
	}
	
	private List<Relationship> listAllRelationships(UUID docId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{			
			System.out.println("************** Listing all Relationships in the Document ***************** ");
			List<Relationship> relList = gClient.getAllRelationships(docId);
			return relList;
		}
		
	}
	
	private Relationship fetchRelationshipById(UUID docId, String relId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			System.out.println("************** Fetching Relationship ***************** ");
			Relationship fetchedRel = gClient.getRelationship(docId, relId);
			return fetchedRel;
		}
		
	}
	
	private void deleteRelationship(UUID docId, String relId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			System.out.println("************** Deleting Relationship ***************** ");
			GenericGrafoResponse resp = gClient.deleteRelationship(docId, relId);
			System.out.println(resp);
		}
	}
	

	private void deleteDocument(UUID docId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{
			System.out.println("************** Deleting Document ***************** ");
			gClient.deleteDocument(docId);
		}

	}

}

