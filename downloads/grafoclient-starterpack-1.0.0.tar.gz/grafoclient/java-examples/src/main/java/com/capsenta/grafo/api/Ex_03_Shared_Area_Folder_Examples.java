package com.capsenta.grafo.api;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Iterator;

import com.capsenta.grafo.GrafoClient;
import com.capsenta.grafo.entity.resource.Folder;
import com.capsenta.grafo.entity.resource.ResourceSearchCriteria;

public class Ex_03_Shared_Area_Folder_Examples {

	private Folder parentShareFolder;
	
	private Folder shareFolderWithoutChildFolder1;
	
	private Folder shareFolderWithoutChildFolder2;
	
	private Folder shareChildFolder1;
	
	private Folder shareChildFolder2;
	
	public static void main(String[] args) {
		try {
			Ex_03_Shared_Area_Folder_Examples ex = new Ex_03_Shared_Area_Folder_Examples();
			ex.execute();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void execute() throws Exception {
		System.out.println("Create Shared Area Folders without Parent Folder");
		createShareFoldersWithoutParent();
		
		System.out.println("Create Shared Area Folders with Parent Folder");
		createShareFoldersWithParentFolder();
		
		System.out.println("List Shared Area Folders without Parent");
		listShareFoldersAtTopLevel();
		
		System.out.println("List Shared Area Folders with Parent");
		listShareFoldersWithParentFolder();
		
		System.out.println("Get Shared Area Folder By Id");
		getShareFolderById();
		
		System.out.println("Update Shared Area Folder");
		updateShareFolder();
	}

	private void createShareFoldersWithoutParent() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			Folder folder1 = new Folder(); folder1.setTitle("Parent ShareFolder");
			parentShareFolder = gClient.createShareFolder(folder1);
			
			Folder folder2 = new Folder(); folder2.setTitle("ShareFolderWithoutChildFolder 1");
			shareFolderWithoutChildFolder1 = gClient.createShareFolder(folder2);
			
			Folder folder3 = new Folder(); folder3.setTitle("ShareFolderWithoutChildFolder 2");
			shareFolderWithoutChildFolder2 = gClient.createShareFolder(folder3);
			
		}
	}
	
	private void createShareFoldersWithParentFolder() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			Folder folder4 = new Folder(); folder4.setTitle("Shared Child Folder1"); folder4.setParent(parentShareFolder.getId());
			shareChildFolder1 = gClient.createShareFolder(folder4);
			
			Folder folder5 = new Folder(); folder5.setTitle("Shared Child Folder2"); folder5.setParent(parentShareFolder.getId());
			shareChildFolder2 = gClient.createShareFolder(folder5);
		}
	}
	
	private void listShareFoldersAtTopLevel() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			ResourceSearchCriteria resourceSearch = new ResourceSearchCriteria().limit(2).page(1).deleted(false).createdOn(LocalDate.now());
			for (Iterator<Folder> folderIter = gClient.getShareFolders(resourceSearch); folderIter.hasNext();) {
				System.out.println(folderIter.next());
			}
		}
	}
	
	private void listShareFoldersWithParentFolder() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			ResourceSearchCriteria resourceSearch = new ResourceSearchCriteria().limit(5).page(1).parent(parentShareFolder.getId()).deleted(false).createdOn(LocalDate.now());
			for (Iterator<Folder> folderIter = gClient.getShareFolders(resourceSearch); folderIter.hasNext();) {
				System.out.println(folderIter.next());
			}
		}
	}
	
	
	private void getShareFolderById() throws Exception {
		try (GrafoClient gClient = new GrafoClient();) {
			Folder folder = gClient.getShareFolder(shareChildFolder1.getId());
			System.out.println("Share Folder Fetched: " + folder);
		}
	}
	
	private void updateShareFolder() throws Exception {
		try (GrafoClient gClient = new GrafoClient();) {		
			Folder folder = gClient.getShareFolder(shareFolderWithoutChildFolder1.getId());
			folder.setTitle("titleupdate");
			Folder updatedFolder = gClient.updateShareFolder(folder);
			System.out.println("Share Folder Updated: " + updatedFolder);
		}
	}
}
