'use strict';

var GrafoClient = require('grafo-client/lib/grafo_client');
var Document = require('grafo-client/lib/models/document');

var ColorPalette = require('grafo-client/lib/models/color_palette');

var config = require('./conf/conf.js');

this.execute = async function() {
    console.log("Starting Grafo Client Relationship CRUD Example");
    var grafoClient = new GrafoClient();
    console.log("Authenticating to Grafo Server with the provided config : ");
    console.log(config);
    await grafoClient.init(config);
    console.log("Authenticated");

    var ekgDoc = await createEmptyEkgDoc(grafoClient);

    var conceptIdList = await createConcepts(grafoClient, ekgDoc);

    await doRelationshipCrudOps(grafoClient, ekgDoc, conceptIdList);

    await deleteEkgDocument(grafoClient, ekgDoc.id);

    console.log("closing connection");
    await grafoClient.close();
};

var createEmptyEkgDoc = async function(grafoClient) {
    var d = new Date();
    var document1 = new Document(); document1.setTitle('TestDoc_' + d.getTime());
    console.log("Creating Document with name " +  document1.getTitle() + " in default location ... ");
    var docDetails =  await grafoClient.createDocument(document1);
    var ekgDoc = await grafoClient.createEkgDocument(docDetails);
    console.log("Created Empty EKG Document with Id " + ekgDoc.id);
    return ekgDoc;
};

var createConcepts = async function(grafoClient, ekgDoc){
    var conceptIdList = [];

    for(var i=0; i< 2; i++){
        var concept = await ekgDoc.addConcept("Test " + i);
        conceptIdList.push(concept.getId());
    }
    return conceptIdList;
};

var doRelationshipCrudOps = async function(grafoClient, ekgDoc, conceptIdList) {
    /*
        ADDING RELATIONSHIPS
        Parameters to addRelationship method in order are listed below
        label, fromConceptId, toConceptId, specialization, description,
        color, fields, cardinalityType, cardinality, positionX, positionY, iri, id
     */
    console.log("Adding relationships to doc ...");
    var rel1 = await ekgDoc.addRelationship("firstlink", conceptIdList[0], conceptIdList[1]);
    var rel2 = await ekgDoc.addRelationship("secondlink", conceptIdList[0], conceptIdList[1]);
    var rel3 = await ekgDoc.addRelationship("thirdlink", conceptIdList[0], conceptIdList[1]);
    var rel4 = await ekgDoc.addRelationship("selflink", conceptIdList[0], conceptIdList[0]);
    console.log("Three relationships added");

    /*
        UPDATING RELATIONSHIPS
         Parameters to updateConcept method in order are listed below
         label, specialization, description, color, fields,
         cardinalityType, cardinality, positionX, positionY, iri, id) {
     */
    console.log("Updating Relationship ....");
    var updatedRel1 = await ekgDoc.updateRelationship("peerlink1updated", null,
        "Updated Relationship", ColorPalette.color.CORAL_RED, null, null, null, null, null, null, null,
        rel1.getId());
    var updatedRel2 = await ekgDoc.updateRelationship("peerlink2updated", null,
        "Updated Relationship", null, null, null, "exact", "100", null, null, null,
        rel2.getId());
    console.log("Two Relationships updated");

    /*
        DELETING RELATIONSHIP
     */
    console.log("Deleting Relationship ....");
    await ekgDoc.deleteRelationship(rel3.getId());
    console.log("Relationship Deleted");

    /*
        LISTING ALL RELATIONSHIPS IN THE DOCUMENT
     */
    console.log("Listing all the relationships in the document........");
    var relList = await ekgDoc.getRelationships();
    console.log(relList);

    /*
        FETCHING ONE RELATIONSHIP
     */

    console.log("Fetching Relationship");
    var fetchedRel = ekgDoc.getRelationship(rel4.getId());
    console.log(fetchedRel.toObject());
};


var deleteEkgDocument = async function(grafoClient, ekgDocId) {
    console.log("Deleting Document....");
    await grafoClient.deleteEkgDocument(ekgDocId);
};

module.exports = {
    execute: this.execute
};