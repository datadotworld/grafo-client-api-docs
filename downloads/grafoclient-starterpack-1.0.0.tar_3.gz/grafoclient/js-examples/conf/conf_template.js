module.exports = {
	GRAFO: {
		SECURE: false,
		SERVER: "localhost",
		PORT: 1337,
		DEFAULT_LOGIN: {
			EMAIL: "youremail",
			PASSSWORD: "yourpassword",
			TOKEN: "yourtoken"
		},
		OT: {
	    	UPDATE_INTERVAL_IN_MS: 100
	    }
	}
}
