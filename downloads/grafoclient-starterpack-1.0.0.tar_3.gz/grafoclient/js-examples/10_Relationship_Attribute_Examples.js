'use strict';

var GrafoClient = require('grafo-client/lib/grafo_client');
var Document = require('grafo-client/lib/models/document');
var DataTypes = require('grafo-client/lib/models/datatypes');

var config = require('./conf/conf.js');

this.execute = async function() {
    console.log("Starting Grafo Client Relationship Attribute CRUD Example");
    var grafoClient = new GrafoClient();
    console.log("Authenticating to Grafo Server with the provided config : ");
    console.log(config);
    await grafoClient.init(config);
    console.log("Authenticated");

    var ekgDoc = await createEmptyEkgDoc(grafoClient);

    var relationshipId = await createRelationship(grafoClient, ekgDoc);

    await doRelAttributeCrudOps(grafoClient, ekgDoc, relationshipId);

    await deleteEkgDocument(grafoClient, ekgDoc.id);

    console.log("closing connection");
    await grafoClient.close();
};

var createEmptyEkgDoc = async function(grafoClient) {
    var d = new Date();
    var document1 = new Document(); document1.setTitle('TestDoc_' + d.getTime());
    console.log("Creating Document with name " +  document1.getTitle() + " in default location ... ");
    var docDetails =  await grafoClient.createDocument(document1);
    var ekgDoc = await grafoClient.createEkgDocument(docDetails);
    console.log("Created Empty EKG Document with Id " + ekgDoc.id);
    return ekgDoc;
};

var createRelationship = async function(grafoClient, ekgDoc){
    var conceptCreated01 = await ekgDoc.addConcept("TestA");
    var conceptCreated02 = await ekgDoc.addConcept("TestB");

    var rel1 = await ekgDoc.addRelationship("firstlink", conceptCreated01.getId(), conceptCreated02.getId());

    return rel1.getId();
};

var doRelAttributeCrudOps = async function(grafoClient, ekgDoc, relId) {
    /*
        ADDING ATTRIBUTES TO RELATIONSHIP
        Parameters to addAttributeToConcept method in order are listed below
        label, description, fields, xsdDataType, cardinalityType, cardinality, iri, id, relationshipId
     */
    console.log("Adding attribute to Relationship ...");
    await ekgDoc.addRelationshipAttribute("First Attribute", null, null, null,
        null, null, null, null, relId);
    await ekgDoc.addRelationshipAttribute("Second Attribute", "This is the second attribute", null, null,
        null, null, null, null, relId);
    await ekgDoc.addRelationshipAttribute("Third Attribute", null, [{"title":"Hello"}, {"text": "World"}],
        DataTypes.XsdDataType.DATETIME, null, null, null, null, relId);
    console.log("Three attributes added");

    /*
        LISTING ALL RELATIONSHIP ATTRIBUTES
    */
    console.log("Listing all the attributes for the relationship in the document........");
    var attributeList = await ekgDoc.getRelationshipAttributes(relId);
    console.log(attributeList);


    /*
        FETCHING ONE ATTRIBUTE
     */

    console.log("Fetching Attribute");
    var fetchedAttribute = await ekgDoc.getRelationshipAttribute(relId, attributeList[0].id);
    console.log(fetchedAttribute.toObject());


    /*
        UPDATING ATTRIBUTES TO RELATIONSHIP
        Parameters to updateAttributeToConcept method in order are listed below
        label, description, fields, xsdDataType, cardinalityType, cardinality, iri, id, relationshipId
     */
    console.log("Updating Attribute to relationship ....");
    await ekgDoc.updateRelationshipAttribute("Hello Label", "Updated Attribute",
        null, null, null, null, null, attributeList[1].id, relId);
    console.log("Updated......");

    /*
        DELETING ATTRIBUTE
     */
    console.log("Deleting Attribute ....");
    await ekgDoc.deleteRelationshipAttribute(relId, attributeList[2].id);
    console.log("Attribute Deleted");

};


var deleteEkgDocument = async function(grafoClient, ekgDocId) {
    console.log("Deleting Document....");
    await grafoClient.deleteEkgDocument(ekgDocId);
};

module.exports = {
    execute: this.execute
};