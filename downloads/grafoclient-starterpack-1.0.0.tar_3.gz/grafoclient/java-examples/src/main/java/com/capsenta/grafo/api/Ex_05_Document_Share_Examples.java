package com.capsenta.grafo.api;

import java.io.IOException;
import java.util.List;

import com.capsenta.grafo.GrafoClient;
import com.capsenta.grafo.entity.GenericGrafoResponse;
import com.capsenta.grafo.entity.resource.Document;
import com.capsenta.grafo.entity.resource.DocumentShare;
import com.capsenta.grafo.entity.resource.Permission;

public class Ex_05_Document_Share_Examples {

	private Document docCreated;
	private List<DocumentShare> shareList;
	
	public static void main(String[] args) {
		try {
			Ex_05_Document_Share_Examples ex = new Ex_05_Document_Share_Examples();
			ex.execute();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void execute() throws Exception {
		System.out.println("create Document to Share");
		createDocument();
		System.out.println("Share document");
		createDocumentShare();
		System.out.println("Fetch Document Shares");
		getDocumentShares();
		System.out.println("Fetch Document Share");
		getDocumentShare();
		System.out.println("Update Document Share");
		updateDocumentShare();
		System.out.println("Delete Document Share");
		deleteDocumentShare();
	}
	
	private void createDocument() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			Document doc = new Document();
			doc.setTitle("Doc for sharing");
			docCreated = gClient.createDocument(doc);
			System.out.println("Document created: "+docCreated);
		}
	}
	
	public void createDocumentShare() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			DocumentShare newShare = new DocumentShare();
			newShare.setSharedWithEmail("testcapsenta2@gmail.com");
			newShare.setPermissions(Permission.VIEW);
			newShare.setMessage("Sharing a document");
			shareList = gClient.createDocumentShare(docCreated.getId(), newShare);
			shareList.forEach(share -> System.out.println(share)) ;
		}
	}
	
	public void getDocumentShares() throws IOException {
		try(GrafoClient gClient = new GrafoClient();) {
			List<DocumentShare> docShares = gClient.getDocumentShares(docCreated.getId());			
			docShares.forEach(share -> System.out.println(share)) ;
		}
	}
	
	public void getDocumentShare() throws IOException {
		try(GrafoClient gClient = new GrafoClient();) {
			System.out.println(shareList.get(0));
			DocumentShare docShare = gClient.getDocumentShare(docCreated.getId(), shareList.get(0).getId());			
			System.out.println(docShare) ;
		}
	}
	
	public void updateDocumentShare() throws IOException {
		try(GrafoClient gClient = new GrafoClient();) {
			DocumentShare shareForUpdate = gClient.getDocumentShare(docCreated.getId(), shareList.get(0).getId());
			shareForUpdate.setPermissions(Permission.COMMENT);
			List<DocumentShare> docShare = gClient.updateDocumentShare(shareForUpdate);
			System.out.println(docShare) ;
		}
	}
	
	public void deleteDocumentShare() throws IOException {
		try(GrafoClient gClient = new GrafoClient();) {
			GenericGrafoResponse resp = gClient.deleteDocumentShare(docCreated.getId(), shareList.get(0).getId());			
			System.out.println(resp) ;
		}
	}

}
