package com.capsenta.grafo.api;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.capsenta.grafo.GrafoClient;
import com.capsenta.grafo.entity.resource.Document;
import com.capsenta.grafo.entity.resource.ResourceSearchCriteria;

public class Ex_04_Documents_Shared_With_Me_Examples {
	
	private List<Document> docList = new ArrayList<>();
	
	public static void main(String[] args) {
		try {
			Ex_04_Documents_Shared_With_Me_Examples ex = new Ex_04_Documents_Shared_With_Me_Examples();
			ex.execute();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void execute() throws Exception {
		System.out.println("List Documents without Parent");
		listSharedDocumentsAtTopLevel();
		
		System.out.println("Get Document By Id");
		getSharedDocumentById();
	}
	
	private void listSharedDocumentsAtTopLevel() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			ResourceSearchCriteria docSearchCrit = new ResourceSearchCriteria().limit(2).page(1).deleted(false).createdBefore(LocalDate.now());
			for (Iterator<Document> docIter = gClient.getSharedDocumentsWithMe(docSearchCrit); docIter.hasNext();) {
				Document document = docIter.next();
				if(document != null)
					docList.add(document);
				
				System.out.println(document);
			}
		}
	}
	
	private void getSharedDocumentById() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			if(!docList.isEmpty()) {
				Document doc = gClient.getSharedDocumentWithMe(docList.get(0).getId());
				System.out.println("Document fetched: " + doc);
			}
		}
	}
}
