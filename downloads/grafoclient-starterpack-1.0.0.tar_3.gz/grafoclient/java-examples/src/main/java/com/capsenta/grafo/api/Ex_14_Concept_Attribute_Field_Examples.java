package com.capsenta.grafo.api;

import java.io.IOException;
import java.util.List;

import com.capsenta.grafo.GrafoClient;
import com.capsenta.grafo.entity.GenericGrafoResponse;
import com.capsenta.grafo.entity.ekg.Attribute;
import com.capsenta.grafo.entity.ekg.AttributeGroup;
import com.capsenta.grafo.entity.ekg.Concept;
import com.capsenta.grafo.entity.ekg.Field;
import com.capsenta.grafo.entity.resource.Document;

public class Ex_14_Concept_Attribute_Field_Examples {
	
	private Document document;
	
	private Concept concept;
	
	private Attribute attr;
	
	private List<Field> fieldList;
	
	
	public static void main(String[] args) {
		try {
			Ex_14_Concept_Attribute_Field_Examples ex = new Ex_14_Concept_Attribute_Field_Examples();
			ex.execute();			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void execute() throws Exception {
		System.out.println("Creating Document, Adding Concepts and attributes to it");
		createDocumentAndAddConceptAndAttribute();
		
		System.out.println("Add Fields to Concept Attribute");
		addFieldsToConceptAttribute();
		
		System.out.println("List Fields in a Concept Attribute");
		listFieldsInConceptAttribute();
		
		System.out.println("Get Concept Attribute Field By Id");
		getConceptAttributeFieldById();
		
		System.out.println("Update Concept Attribute Field");
		updateConceptAttributeField();
		
		System.out.println("Delete Concept Attribute Field");
		deleteConceptAttributeField();
		
		System.out.println("Delete Document");
		deleteDocument();
	}	

	private void createDocumentAndAddConceptAndAttribute() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			
			//Create Document
			Document doc = new Document();
			doc.setTitle("Concept Field crud ops");
			document = gClient.createDocument(doc);
			
			//Add Concept
			Concept conceptForAdd1 = new Concept("Test1");
			concept = gClient.createConcept(document.getId(), conceptForAdd1);
			
			//Add Concept Attribute
			Attribute attr1 = new Attribute("Attr1");
			AttributeGroup attrGrp = gClient.addConceptAttribute(document.getId(), concept.getId(), attr1);
			
			attr = attrGrp.getAttributes().get(0);
		}
	}
	
	private void addFieldsToConceptAttribute() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			
			
			Field field1 = new Field("field1"); field1.setText("text1");
			gClient.addConceptAttributeField(document.getId(), concept.getId(), attr.getId(), field1);
			
			Field field2 = new Field("field2"); field2.setText("text2");
			gClient.addConceptAttributeField(document.getId(), concept.getId(), attr.getId(), field2);
		}
	}
	
	private void listFieldsInConceptAttribute() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			fieldList = gClient.getConceptAttributeFields(document.getId(), concept.getId(), attr.getId());
			System.out.println("Fields in "+concept.getId()+" with attribute " + attr.getId() + " are " +fieldList);
		}
	}
	
	private void getConceptAttributeFieldById() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			Field fieldFetched = gClient.getConceptAttributeField(document.getId(), concept.getId(), attr.getId(), fieldList.get(1).getId());
			System.out.println("Fetched Concept Attribute: " + fieldFetched);
		}
	}
	
	private void updateConceptAttributeField() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			Field fieldToUpdate = gClient.getConceptAttributeField(document.getId(), concept.getId(), attr.getId(), fieldList.get(0).getId());			
			fieldToUpdate.setTitle("updatedField1");
			fieldToUpdate.setText("updatedText1");
			AttributeGroup attrGroup = gClient.updateConceptAttributeField(document.getId(), concept.getId(), attr.getId(), fieldToUpdate);
			System.out.println("Updated Concept Attribute: " + attrGroup.getAttributes().get(0));
		}
	}
	
	private void deleteConceptAttributeField() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			GenericGrafoResponse response = gClient.deleteConceptAttributeField(document.getId(), concept.getId(),  attr.getId(),  fieldList.get(1).getId());
			System.out.println(response);
		}
	}
	
	private void deleteDocument() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			gClient.deleteDocument(document.getId());
		}
	}
}
