package com.capsenta.grafo.api;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

import com.capsenta.grafo.GrafoClient;
import com.capsenta.grafo.entity.GenericGrafoResponse;
import com.capsenta.grafo.entity.ekg.Attribute;
import com.capsenta.grafo.entity.ekg.AttributeGroup;
import com.capsenta.grafo.entity.ekg.CardinalityType;
import com.capsenta.grafo.entity.ekg.Concept;
import com.capsenta.grafo.entity.resource.Document;

public class Ex_08_Concept_Attribute_Examples 
{
	public static void main(String[] args) {
		try {
			Ex_08_Concept_Attribute_Examples ex = new Ex_08_Concept_Attribute_Examples();
			ex.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void execute() throws Exception {
		UUID docId = createDocument();
		
		Concept newConcept = createConcept(docId);
		System.out.println(newConcept);
		
		Attribute newAttribute = addAttribute(docId, newConcept.getId());
		System.out.println(newAttribute);
		
		Attribute updatedAttribute = updateAttribute(docId, newConcept.getId(), newAttribute);
		System.out.println(updatedAttribute);
		
		List<Attribute> listAttributes = listAllConceptAttributes(docId, newConcept.getId());
		listAttributes.forEach(attr -> System.out.println(attr));
		
		Attribute fetchedAttr = fetchAttributeById(docId, newConcept.getId(), newAttribute.getId());
		System.out.println(fetchedAttr);
		
		deleteAttribute(docId, newConcept.getId(), fetchedAttr.getId());
		
		deleteDocument(docId);
	}

	private UUID createDocument() throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		)
		{	
			System.out.println("************** Creating Document For Concept Attribute CRUD Demo ***************** ");
			Document newDoc = new Document();
			newDoc.setTitle("My Test Doc " + System.currentTimeMillis());
			Document createdDoc = gClient.createDocument(newDoc);
			return createdDoc.getId();
		}
		
	}
	
	private Concept createConcept(UUID docId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			System.out.println("************** Creating Concept ***************** ");
			Concept concept = new Concept("MyConceptA");
			concept.setDescription("Attribute CRUD");
			Concept newConcept = gClient.createConcept(docId, concept);
			return newConcept;
		}
		
	}
	
	private Attribute addAttribute(UUID docId, String conceptId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{
			System.out.println("************** Adding Attribute to Concept ***************** ");
			Attribute attribute = new Attribute("Attribute1");
			AttributeGroup newAttrGroup = gClient.addConceptAttribute(docId, conceptId, attribute);
			System.out.println("New Attribute Group created: " + newAttrGroup);
			return newAttrGroup.getAttributes().get(0);
		}
	}
	
	private Attribute updateAttribute(UUID docId, String conceptId, Attribute attribute) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			System.out.println("************** Updating Attribute ***************** ");
			attribute.setLabel("Updated Attribute");
			attribute.setCardinalityType(CardinalityType.EXACT);
			attribute.setCardinality("100");
			AttributeGroup newAttrGroup = gClient.updateConceptAttribute(docId, conceptId, attribute);
			return newAttrGroup.getAttributes().get(0);
		}
		
	}
	
	private List<Attribute> listAllConceptAttributes(UUID docId, String conceptId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			//Creating 2 more attributes to demonstrate list attributes
			Attribute attribute2 = new Attribute("Attribute2");
			gClient.addConceptAttribute(docId, conceptId, attribute2);
			
			Attribute attribute3 = new Attribute("Attribute3");
			gClient.addConceptAttribute(docId, conceptId, attribute3);
			
			System.out.println("************** Listing all Attributes for the Concept ***************** ");
			List<Attribute> attrList = gClient.getAllConceptAttributes(docId, conceptId);
			return attrList;
		}
		
	}
	
	private Attribute fetchAttributeById(UUID docId, String conceptId, String attrId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			System.out.println("************** Fetching Attribute ***************** ");
			Attribute fetchedAttr = gClient.getConceptAttribute(docId, conceptId, attrId);
			return fetchedAttr;
		}
		
	}
	
	private void deleteAttribute(UUID docId, String conceptId, String attrId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			System.out.println("************** Deleting Attribute ***************** ");
			GenericGrafoResponse resp = gClient.deleteConceptAttribute(docId, conceptId, attrId);
			System.out.println(resp);
		}
	}
	

	private void deleteDocument(UUID docId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{
			System.out.println("************** Deleting Document ***************** ");
			gClient.deleteDocument(docId);
		}

	}


}

