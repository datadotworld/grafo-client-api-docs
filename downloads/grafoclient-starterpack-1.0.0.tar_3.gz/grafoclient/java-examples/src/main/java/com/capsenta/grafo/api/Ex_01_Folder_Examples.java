package com.capsenta.grafo.api;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Iterator;

import com.capsenta.grafo.GrafoClient;
import com.capsenta.grafo.entity.resource.Folder;
import com.capsenta.grafo.entity.resource.ResourceSearchCriteria;

public class Ex_01_Folder_Examples {
	
	private Folder parentFolder;
	
	private Folder folderWithoutChildFolder1;
	
	private Folder folderWithoutChildFolder2;
	
	private Folder childFolder1;
	
	private Folder childFolder2;
	
	public static void main(String[] args) {
		try {
			Ex_01_Folder_Examples ex = new Ex_01_Folder_Examples();
			ex.execute();	
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void execute() throws Exception {
		System.out.println("Create Folders without Parent Folder");
		createFoldersWithoutParent();
		
		System.out.println("Create Folders with Parent Folder");
		createFoldersWithParentFolder();
		
		System.out.println("List Folders without Parent");
		listFoldersAtTopLevel();
		
		System.out.println("List Folders with Parent");
		listFoldersWithParentFolder();
		
		System.out.println("Get Folder By Id");
		getFolderById();
		
		System.out.println("Update Folder");
		updateFolder();
		
		System.out.println("Delete Folders");
		deleteFolders();
	}
	
	private void createFoldersWithoutParent() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			Folder folder1 = new Folder(); folder1.setTitle("Parent Folder");
			parentFolder = gClient.createFolder(folder1);
			
			Folder folder2 = new Folder(); folder2.setTitle("FolderWithoutChildFolder 1");
			folderWithoutChildFolder1 = gClient.createFolder(folder2);
			
			Folder folder3 = new Folder(); folder3.setTitle("FolderWithoutChildFolder 2");
			folderWithoutChildFolder2 = gClient.createFolder(folder3);
			
		}
	}
	
	private void createFoldersWithParentFolder() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			Folder folder4 = new Folder(); folder4.setTitle("Child Folder1"); folder4.setParent(parentFolder.getId());
			childFolder1 = gClient.createFolder(folder4);
			
			Folder folder5 = new Folder(); folder5.setTitle("Child Folder2"); folder5.setParent(parentFolder.getId());
			childFolder2 = gClient.createFolder(folder5);
		}
	}
	
	private void listFoldersAtTopLevel() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			ResourceSearchCriteria resourceSearch = new ResourceSearchCriteria().limit(2).page(1).deleted(false).createdOn(LocalDate.now());
			for (Iterator<Folder> folderIter = gClient.getFolders(resourceSearch); folderIter.hasNext();) {
				System.out.println(folderIter.next());
			}
		}
	}
	
	private void listFoldersWithParentFolder() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			ResourceSearchCriteria resourceSearch = new ResourceSearchCriteria().limit(5).page(1).parent(parentFolder.getId()).deleted(false).createdOn(LocalDate.now());
			for (Iterator<Folder> folderIter = gClient.getFolders(resourceSearch); folderIter.hasNext();) {
				System.out.println(folderIter.next());
			}
		}
	}
	
	
	private void getFolderById() throws Exception {
		try (GrafoClient gClient = new GrafoClient();) {
			Folder folder = gClient.getFolder(childFolder1.getId());
			System.out.println("Folder Fetched: " + folder);
		}
	}
	
	private void updateFolder() throws Exception {
		try (GrafoClient gClient = new GrafoClient();) {		
			Folder folder = gClient.getFolder(folderWithoutChildFolder1.getId());
			folder.setTitle("titleupdate");
			Folder updatedFolder = gClient.updateFolder(folder);
			System.out.println("Folder Updated: " + updatedFolder);
		}
	}
	
	private void deleteFolders() throws Exception {
		try (GrafoClient gClient = new GrafoClient();) {		
			gClient.deleteFolder(parentFolder.getId());
			gClient.deleteFolder(folderWithoutChildFolder1.getId());
			gClient.deleteFolder(folderWithoutChildFolder2.getId());
			System.out.println("Folders deleted");
		}
	}
}
