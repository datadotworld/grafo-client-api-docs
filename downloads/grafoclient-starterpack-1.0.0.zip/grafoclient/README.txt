1. cd java-examples/conf
2. Make a copy of grafo-client-template.properties. Name the file as grafo-client.properties
3. Put the appropriate values of userid, password and token in that file
4. cd js-examples/conf
5. Make a copy of conf_template.js. Name the file as conf.js
6. Put the appropriate values of userid, password and token in that file
7. Run ./mvnw clean package

This will download the dependencies (including grafo-client) and run the examples as test
You can run java-examples (from that directory) with command mvn exec:java  or individually running the Java files. 
conf file is provided as -Dapp.configurationFile=grafo-client.properties 

You can run js-examples (from that directory) "node <example js file name>"