'use strict';

var GrafoClient = require('grafo-client/lib/grafo_client');
var Document = require('grafo-client/lib/models/document');

var config = require('./conf/conf.js');

this.execute = async function() {
    console.log("Starting Grafo Client Relationship Field CRUD Example");
    var grafoClient = new GrafoClient();
    console.log("Authenticating to Grafo Server with the provided config : ");
    console.log(config);
    await grafoClient.init(config);
    console.log("Authenticated");

    //Creating new ekg Document and Add concept to it
    var ekgDoc = await createEmptyEkgDoc(grafoClient);

    await addConcepts(ekgDoc);

    var relationship = await addRelationship(ekgDoc);

    var attributeGroup = await addAttributeToRelationship(ekgDoc, relationship);

    var attribute = attributeGroup.attributeList[0];

    await doRelationshipAttributeFieldCrudOps(ekgDoc, relationship, attribute);

    await deleteEkgDocument(grafoClient, ekgDoc.id);

    console.log("closing connection");
    await grafoClient.close();
};

var createEmptyEkgDoc = async function(grafoClient) {
    var d = new Date();
    var document1 = new Document(); document1.setTitle('TestDoc_' + d.getTime());
    console.log("Creating Document with name " +  document1.getTitle() + " in default location ... ");
    var docDetails =  await grafoClient.createDocument(document1);
    var ekgDoc = await grafoClient.createEkgDocument(docDetails);
    console.log("Created Empty EKG Document with Id " + ekgDoc.id);
    return ekgDoc;
};

var addConcepts = async function(ekgDoc) {
    console.log("Adding Concept to doc ...");
    await ekgDoc.addConcept("FromConcept");
    await ekgDoc.addConcept("ToConcept");
};

var addRelationship = async function(ekgDoc) {
    console.log("Adding Relationship to doc ...");
    var concepts = await ekgDoc.getConcepts();
    var fromConceptId = concepts[0].id;
    var toConceptId = concepts[1].id;
    var relationship = await ekgDoc.addRelationship("Relation1", fromConceptId, toConceptId);
    return relationship;
};

var addAttributeToRelationship = async function(ekgDoc, relationship) {
    var createdRelationshipAttr = await ekgDoc.addRelationshipAttribute("attr1", "attr to add field",null,
        null, null, null, "attrIri", null, relationship.id);
    return createdRelationshipAttr;
};

var doRelationshipAttributeFieldCrudOps = async  function(ekgDoc, relationship, attribute) {
    /*
        ADDING RELATIONSHIP ATTRIBUTE FIELDS
        Parameters to addRelationshipAttributeField method in order are listed below
        Title, Text, RelationshipId, AttributeId
     */
    console.log("Adding Relationship Attribute Fields to Relationship ...");
    var relationshipAttributeFieldCreated01 = await ekgDoc.addRelationshipAttributeField("field1",
                                                    "field text1", relationship.id, attribute.id);
    var relationshipAttributeFieldCreated02 = await ekgDoc.addRelationshipAttributeField("field2",
                                                    "", relationship.id, attribute.id);
    var relationshipAttributeFieldCreated03 = await ekgDoc.addRelationshipAttributeField("field3",
                                                    "field text 3", relationship.id, attribute.id);
    console.log("3 Relationship Attribute Fields added");

    /*
        LISTING ALL RELATIONSHIP ATTRIBUTE FIELDS IN THE RELATIONSHIP
     */
    console.log("Listing all the Relationship Attribute fields in the Relationship........");
    var relationshipAttributeFieldList = await ekgDoc.getRelationshipAttributeFields(relationship.id, attribute.id);
    console.log(relationshipAttributeFieldList);

    /*
        FETCHING ONE RELATIONSHIP ATTRIBUTE FIELD
     */
    var relAttrFields = await ekgDoc.getRelationshipAttributeFields(relationship.id, attribute.id);
    var fieldId = relAttrFields[1].id;
    console.log("Fetching Relationship Attribute Field with id "+fieldId);
    var fetchedRelationshipAttributeField = await ekgDoc.getRelationshipAttributeField(relationship.id,
                                            attribute.id, fieldId);
    console.log(fetchedRelationshipAttributeField);

    /*
        UPDATING RELATIONSHIP ATTRIBUTE FIELD
        Parameters to updateRelationshipField method in order are listed below
        Title, Text, FieldId, RelationshipId
     */
    var fieldIdToUpdate = relAttrFields[0].id;
    console.log("Updating Relationship Attribute Field with id "+fieldIdToUpdate);
    var updatedRelationshipAttributeField = await ekgDoc.updateRelationshipAttributeField("updated Field",
                                                    "updated Text", fieldIdToUpdate,
                                                    relationship.id, attribute.id);
    console.log("Updated Relationship Attribute Fields");
    console.log(await ekgDoc.getRelationshipAttributeFields(relationship.id, attribute.id));

    /*
        DELETING RELATIONSHIP ATTRIBUTE FIELD
     */
    var relAttributeFields = await ekgDoc.getRelationshipAttributeFields(relationship.id, attribute.id);
    var fieldIdToDelete = relAttributeFields[2].id;
    console.log("Deleting Relationship Attribute Field with id "+fieldIdToDelete);
    await ekgDoc.deleteRelAttributeField(relationship.id, attribute.id, fieldIdToDelete);
    console.log("Relationship Attribute Field Deleted");

};

var deleteEkgDocument = async function(grafoClient, ekgDocId) {
    console.log("Deleting Document....");
    await grafoClient.deleteEkgDocument(ekgDocId);
};

module.exports = {
    execute: this.execute
};