'use strict';

var GrafoClient = require('grafo-client/lib/grafo_client');

var FolderSearchCriteria = require('grafo-client/lib/models/resource_search_criteria');
var Folder = require('grafo-client/lib/models/folder');

var config = require('./conf/conf.js');
var moment = require('moment');

this.execute = async function() {
    console.log("Starting Grafo Client Folders Example");
    var grafoClient = new GrafoClient();
    console.log("Authenticating to Grafo Server with the provided config");
    await grafoClient.init(config);
    console.log("Authenticated");

    //Creating Folders Without Parent
    console.log("Creating Folders");
    //createFolder(folder)
    var folder1 = new Folder(); folder1.title = 'ParentFolder';
    var parentFolder = await grafoClient.createFolder(folder1);
    var folder2 = new Folder(); folder2.title = 'FolderWithoutChildFolder 1';
    var folderWithoutChildFolder1 = await grafoClient.createFolder(folder2);
    var folder3 = new Folder(); folder3.title = 'FolderWithoutChildFolder 2';
    var folderWithoutChildFolder2 = await grafoClient.createFolder(folder3);

    //Creating Folders With Parent
    var folder4 = new Folder(); folder4.title = 'Child Folder1'; folder4.parent = parentFolder.id;
    var childFolder1 = await grafoClient.createFolder(folder4);
    var folder5 = new Folder(); folder5.title = 'Child Folder2'; folder5.parent = parentFolder.id;
    var childFolder2 = await grafoClient.createFolder(folder5);

    //*****************************************************************

    var today = moment(new Date()).format("YYYY-MM-DD");
    console.log(today);
    //list Folders without Parent
    console.log("Listing Folders At Top Level");
    //ResourceSearchCriteria(limit, page, parent, deleted)
    //Folders can be listed by providing date ranges such as createdOn(date), createdBefore(date),
    //createdAfter(date), createdOnOrBefore(date), createdOnOrAfter(date),
    //createdBetween(startDate, endDate, inclType), createdBetween(startDate, endDate)
    var folderSearchCriteria1 = new FolderSearchCriteria().setLimit(5).setPage(1).setDeleted(false).createdOn(today);
    var listAllFoldersWithoutParent = await grafoClient.getFolders(folderSearchCriteria1);
    console.log("allFoldersWithoutParent****");
    for (var i=0;i<listAllFoldersWithoutParent.length;i++) {
        console.log(listAllFoldersWithoutParent[i]);
    }
    //console.log(listAllFoldersWithoutParent);

    // list all Folders
    console.log("List All My Folders");
    var page = 1;
    var folderSearchCriteria3 = new FolderSearchCriteria().setLimit(2).setPage(page).setDeleted(false).createdOn(today);
    var folderList = await grafoClient.getFolders(folderSearchCriteria3);
    while(folderList.length > 0) {
        folderList = await grafoClient.getFolders(folderSearchCriteria3.setPage(page).createdOn(today));
        if(folderList.length > 0)
            console.log(folderList);

        page++;
    }

    // list Folders within another folder by specifying parent folder id
    console.log("Listing Folders Within ParentFolder");
    var folderSearchCriteria2 = new FolderSearchCriteria().setLimit(5).setPage(1).setParent(parentFolder.id).setDeleted(false).createdOn(today);
    var listAllFoldersWithParent = await grafoClient.getFolders(folderSearchCriteria2);
    console.log("allFoldersWithParent ParentFolder****");
    console.log(listAllFoldersWithParent);

    //*****************************************************************

    //Get Folder By Id
    console.log("Get Folder By Id");
    //getFolder(folderId)
    var fetchedFolderById = await grafoClient.getFolder(childFolder1.id);
    console.log("Get Folder by Id*******");
    console.log(fetchedFolderById);

    //*****************************************************************

    //Updating Folder Without Parent
    console.log("Updating Folder");
    //updateFolder(folder)
    var folder6 = new Folder(); folder6.id = folderWithoutChildFolder1.id; folder6.title = 'updated Folder';
    var updatedFolder1 = await grafoClient.updateFolder(folder6);
    console.log("Updated Folder*****");
    console.log(updatedFolder1);

    //*****************************************************************

    //Deleting Folders
    console.log("Deleting Folders");
    // deleteFolder(folderId)
    await grafoClient.deleteFolder(parentFolder.id);
    await grafoClient.deleteFolder(folderWithoutChildFolder1.id);
    await grafoClient.deleteFolder(folderWithoutChildFolder2.id);
    await grafoClient.deleteFolder(childFolder1.id);
    await grafoClient.deleteFolder(childFolder2.id);
    console.log("Folders Deleted");

    //*****************************************************************
    console.log("closing connection... ");
    await grafoClient.close();
};

module.exports = {
  execute: this.execute
};