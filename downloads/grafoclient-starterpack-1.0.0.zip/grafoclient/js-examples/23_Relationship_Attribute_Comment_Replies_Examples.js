'use strict';

var GrafoClient = require('grafo-client/lib/grafo_client');
var config = require('./conf/conf.js');
var ReplySearchCriteria = require('grafo-client/lib/models/reply_search_criteria');
var moment = require('moment');

this.execute = async function() {
    try {
        console.log("Starting Grafo Client Example");
        var grafoClient = new GrafoClient();
        console.log("Authenticating to Grafo Server with the provided config : ");
        console.log(config);
        await grafoClient.init(config);
        console.log("Authenticated");

        await getRelationshipAttributeCommentReplies(grafoClient);

        console.log("closing connection");
        await grafoClient.close();
    } catch (err) {
        console.log(err);
    }
};
/* To run this example
 set DocId, RelationshipId, attributeId and CommentId to your existing docId, relationshipId,
 attributeId and conversationId of relationship attribute's comments */
var getRelationshipAttributeCommentReplies = async function(grafoClient) {
    var replySearchCriteria = new ReplySearchCriteria()
        .setDocId("6fa870a0-e568-44d9-b425-2681744f8172")
        .setRelationshipId("link-860f72a4-2015-4f58-b6cf-dde0d653b5cc")
        .setAttributeId("linkattr-0f47614f-d0d7-401f-a275-3f9fd04ba5d3")
        .setCommentId("6c60338a-68f2-47d8-ae91-9b9b5bc47144")
        .createdOnOrBefore(moment.now());
    var allReplies = await grafoClient.getReplies(replySearchCriteria);
    console.log(allReplies);
};

exports.execute();

module.exports = {
    execute: this.execute
};