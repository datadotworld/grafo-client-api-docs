'use strict';

var GrafoClient = require('grafo-client/lib/grafo_client');
var config = require('./conf/conf.js');
var ReplySearchCriteria = require('grafo-client/lib/models/reply_search_criteria');
var moment = require('moment');

this.execute = async function() {
    try {
        console.log("Starting Grafo Client Example");
        var grafoClient = new GrafoClient();
        console.log("Authenticating to Grafo Server with the provided config : ");
        console.log(config);
        await grafoClient.init(config);
        console.log("Authenticated");

        await getConceptCommentReplies(grafoClient);

        console.log("closing connection");
        await grafoClient.close();
    } catch (err) {
        console.log(err);
    }
};

/* To run this example
 set DocId, ConceptId and CommentId to your existing docId, conceptId and conversationId
 of concept's comments */
var getConceptCommentReplies = async function(grafoClient) {
    var replySearchCriteria = new ReplySearchCriteria()
        .setDocId("6fa870a0-e568-44d9-b425-2681744f8172")
        .setConceptId("node-14a6143d-9ec1-4049-9bca-25e2c1358365")
        .setCommentId("b269e108-875e-4eb4-a5fc-fc0df7b21da2")
        .createdOnOrBefore(moment.now());
    var allReplies = await grafoClient.getReplies(replySearchCriteria);
    console.log(allReplies);
};

exports.execute();

module.exports = {
    execute: this.execute
};