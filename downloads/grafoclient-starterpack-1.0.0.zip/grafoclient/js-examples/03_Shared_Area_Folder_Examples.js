'use strict';

var GrafoClient = require('grafo-client/lib/grafo_client');

var FolderSearchCriteria = require('grafo-client/lib/models/resource_search_criteria');
var Folder = require('grafo-client/lib/models/folder');

var config = require('./conf/conf.js');
var moment = require('moment');

this.execute = async function() {
    console.log("Starting Grafo Client Shared Folders Example");
    var grafoClient = new GrafoClient();
    console.log("Authenticating to Grafo Server with the provided config : ");
    await grafoClient.init(config);
    console.log("Authenticated");

    //Creating Folders Without Parent
    console.log("Creating Shared Area Folders");
    //createFolder(folder)
    var folder1 = new Folder(); folder1.title = 'ParentShareFolder';
    var parentFolder = await grafoClient.createShareFolder(folder1);
    var folder2 = new Folder(); folder2.title = 'ShareFolderWithoutChildFolder 1';
    var folderWithoutChildFolder1 = await grafoClient.createShareFolder(folder2);
    var folder3 = new Folder(); folder3.title = 'ShareFolderWithoutChildFolder 2';
    var folderWithoutChildFolder2 = await grafoClient.createShareFolder(folder3);

    //Creating Folders With Parent
    var folder4 = new Folder(); folder4.title = 'Child Share Folder1'; folder4.parent = parentFolder.id;
    var childFolder1 = await grafoClient.createShareFolder(folder4);
    var folder5 = new Folder(); folder5.title = 'Child Share Folder2'; folder5.parent = parentFolder.id;
    var childFolder2 = await grafoClient.createShareFolder(folder5);

    //*****************************************************************

    var today = moment(new Date()).format("YYYY-MM-DD");
    //list Folders without Parent
    console.log("Listing Shared Area Folders At Top Level");
    //ResourceSearchCriteria(limit, page, parent, deleted)
    //Folders can be listed by providing date ranges such as createdOn(date), createdBefore(date),
    //createdAfter(date), createdOnOrBefore(date), createdOnOrAfter(date),
    //createdBetween(startDate, endDate, inclType), createdBetween(startDate, endDate)
    var folderSearchCriteria1 = new FolderSearchCriteria().setLimit(5).setPage(1).setDeleted(false).createdOn(today);
    var listAllSharedFoldersWithoutParent = await grafoClient.getShareFolders(folderSearchCriteria1);
    console.log("allFoldersWithoutParent****");
    console.log(listAllSharedFoldersWithoutParent);

    // list all Folders
    console.log("List All Share Folders");
    var page = 1;
    var folderSearchCriteria3 = new FolderSearchCriteria().setLimit(2).setPage(page).setDeleted(false).createdOn(today);
    var shareFolderList = await grafoClient.getShareFolders(folderSearchCriteria3);
    while(shareFolderList.length > 0) {
        shareFolderList = await grafoClient.getShareFolders(folderSearchCriteria3.setPage(page).createdOn(today));
        if(shareFolderList.length > 0)
            console.log(shareFolderList);

        page++;
    }

    // list Folders within another folder by specifying parent folder id
    console.log("Listing Shared Area Folders Within ParentFolder");
    var folderSearchCriteria2 = new FolderSearchCriteria().setLimit(5).setPage(1).setParent(parentFolder.id).setDeleted(false).createdOn(today);
    var listAllFoldersWithParent = await grafoClient.getShareFolders(folderSearchCriteria2);
    console.log("allSharedFoldersWithParent ParentFolder****");
    console.log(listAllFoldersWithParent);

    //*****************************************************************

    //Get Folder By Id
    console.log("Get Share Folder By Id");
    //getFolder(folderId)
    var fetchedShareFolderById = await grafoClient.getShareFolder(childFolder1.id);
    console.log("Get Share Folder by Id*******");
    console.log(fetchedShareFolderById);

    //*****************************************************************

    //Updating Folder Without Parent
    console.log("Updating Share Folder");
    //updateFolder(folder)
    var folder6 = new Folder(); folder6.id = folderWithoutChildFolder1.id; folder6.title = 'updated ShareFolder';
    var updatedFolder1 = await grafoClient.updateShareFolder(folder6);
    console.log("Updated Share Folder*****");
    console.log(updatedFolder1);

    //*****************************************************************

    console.log("closing connection... ");
    await grafoClient.close();
};

module.exports = {
    execute: this.execute
};