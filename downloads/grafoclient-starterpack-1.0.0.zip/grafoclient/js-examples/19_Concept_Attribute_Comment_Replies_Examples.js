'use strict';

var GrafoClient = require('grafo-client/lib/grafo_client');
var config = require('./conf/conf.js');
var ReplySearchCriteria = require('grafo-client/lib/models/reply_search_criteria');
var moment = require('moment');

this.execute = async function() {
    try {
        console.log("Starting Grafo Client Example");
        var grafoClient = new GrafoClient();
        console.log("Authenticating to Grafo Server with the provided config : ");
        console.log(config);
        await grafoClient.init(config);
        console.log("Authenticated");

        await getConceptAttributeCommentReplies(grafoClient);

        console.log("closing connection");
        await grafoClient.close();
    } catch (err) {
        console.log(err);
    }
};

/* To run this example
 set DocId, ConceptId, attributeId and CommentId to your existing docId, conceptId,
 attributeId and conversationId of concept attribute's comments */
var getConceptAttributeCommentReplies = async function(grafoClient) {
    var replySearchCriteria = new ReplySearchCriteria()
        .setDocId("6fa870a0-e568-44d9-b425-2681744f8172")
        .setConceptId("node-14a6143d-9ec1-4049-9bca-25e2c1358365")
        .setAttributeId("attr-8de7a3eb-74b9-4412-a1de-6104de0614")
        .setCommentId("07dd1662-9ff5-45c6-af79-db5ac2dd2662")
        .createdOnOrBefore(moment.now());
    var allReplies = await grafoClient.getReplies(replySearchCriteria);
    console.log(allReplies);
};

exports.execute();

module.exports = {
    execute: this.execute
};