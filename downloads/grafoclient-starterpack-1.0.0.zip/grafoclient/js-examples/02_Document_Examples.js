'use strict';

var GrafoClient = require('grafo-client/lib/grafo_client');

var DocSearchCriteria = require('grafo-client/lib/models/resource_search_criteria');
var Document = require('grafo-client/lib/models/document');
var Folder = require('grafo-client/lib/models/folder');

var config = require('./conf/conf.js');
var moment = require('moment');

this.execute = async function() {
    console.log("Starting Grafo Client Documents Example");
    var grafoClient = new GrafoClient();
    console.log("Authenticating to Grafo Server with the provided config ");
    await grafoClient.init(config);
    console.log("Authenticated");

    console.log("Creating Documents");
    var document1 = new Document(); document1.setTitle('document Without Parent 1');
    var documentWithoutParent1 = await grafoClient.createDocument(document1);
    var document2 = new Document(); document2.setTitle('document Without Parent 2');
    var documentWithoutParent2 = await grafoClient.createDocument(document2);
    var document3 = new Document(); document3.setTitle('document Without Parent 3');
    var documentWithoutParent3 = await grafoClient.createDocument(document3);

    console.log("Creating Parent Folder");
    var folder = new Folder(); folder.title = 'ParentFolder';
    var parentFolder = await grafoClient.createFolder(folder);
    console.log("Creating Documents with Parent");
    var document4 = new Document(); document4.setTitle('childDocument1'); document4.setParent(parentFolder.id);
    var childDocument1 = await grafoClient.createDocument(document4);
    var document5 = new Document(); document5.setTitle('childDocument2'); document5.setParent(parentFolder.id);
    var childDocument2 = await grafoClient.createDocument(document5);
    console.log("New Documents created******");

    //*****************************************************************

    var today = moment(new Date()).format("YYYY-MM-DD");
    //list documents without Parent
    console.log("Listing Documents At Top Level");
    //ResourceSearchCriteria(limit, page, parent, deleted)
    //Documents can be listed by providing date ranges such as createdOn(date), createdBefore(date),
    //createdAfter(date), createdOnOrBefore(date), createdOnOrAfter(date),
    //createdBetween(startDate, endDate, inclType), createdBetween(startDate, endDate)
    var docSearchCriteria1 = new DocSearchCriteria().setLimit(5).setPage(1).setDeleted(false).createdOn(today);
    var allDocsWithoutParent = await grafoClient.getDocuments(docSearchCriteria1);
    console.log("allDocsWithoutParent**********");
    for (var i=0;i<allDocsWithoutParent.length;i++) {
        console.log(allDocsWithoutParent[i]);
    }
    // console.log(allDocsWithoutParent);

    // list all Documents
    console.log("List All My Documents");
    var page = 1;
    var docSearchCriteria3 = new DocSearchCriteria().setLimit(2).setPage(page).setDeleted(false).createdOn(today);
    var documentList = await grafoClient.getDocuments(docSearchCriteria3);
    while(documentList.length > 0) {
        documentList = await grafoClient.getDocuments(docSearchCriteria3.setPage(page).createdOn(today));
        if(documentList.length > 0)
            console.log(documentList);

        page++;
    }


    // list Documents within folder by specifying parent folder id
    console.log("Listing Documents Within ParentFolder");
    var docSearchCriteria2 = new DocSearchCriteria().setLimit(5).setPage(1).setParent(parentFolder.id).setDeleted(false).createdOn(today);
    var listAllDocumentsWithParent = await grafoClient.getDocuments(docSearchCriteria2);
    console.log("allDocumentsWithParent ParentFolder****");
    console.log(listAllDocumentsWithParent);

    //*****************************************************************

    //Get Document By Id
    console.log("Get Document By Id");
    //getMyDocumentById(documentId)
    var fetchedDocumentById = await grafoClient.getDocument(childDocument2.id);
    console.log("Get Document by Id*******");
    console.log(fetchedDocumentById);

    //*****************************************************************

    //Updating Document Without Parent
    console.log("Updating Document");
    //updateDocument(docId, title, iri, iriPrefix, description)
    var docToUpdate = await grafoClient.getDocument(documentWithoutParent2.id);
    docToUpdate.setTitle('updated Document');
    docToUpdate.setIri('updatedDocumentIri');
    docToUpdate.setIriPrefix('updatedDocumentIriPrefix');
    docToUpdate.setDescription('updatedDocumentDescription');
    var updatedDocument1 = await grafoClient.updateDocument(docToUpdate);
    console.log("Updated Document*****");
    console.log(updatedDocument1);

    //*****************************************************************

    //Deleting Documents
    console.log("Deleting Documents");
    //deleteDocument(documentId)
    await grafoClient.deleteDocument(documentWithoutParent1.id);
    await grafoClient.deleteDocument(documentWithoutParent2.id);
    await grafoClient.deleteDocument(documentWithoutParent3.id);
    await grafoClient.deleteDocument(childDocument1.id);
    await grafoClient.deleteDocument(childDocument2.id);
    console.log("Documents Deleted");

    //*****************************************************************
    //delete created folder
    await grafoClient.deleteFolder(parentFolder.id);

    console.log("closing connection... ");
    await grafoClient.close();
};

module.exports = {
    execute: this.execute
};