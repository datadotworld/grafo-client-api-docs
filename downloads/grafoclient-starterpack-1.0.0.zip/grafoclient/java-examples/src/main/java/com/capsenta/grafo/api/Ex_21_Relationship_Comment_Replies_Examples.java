package com.capsenta.grafo.api;

import java.util.Iterator;

import com.capsenta.grafo.GrafoClient;
import com.capsenta.grafo.entity.comment.Reply;
import com.capsenta.grafo.entity.comment.ReplySearchCriteria;

public class Ex_21_Relationship_Comment_Replies_Examples 
{
	
	public static void main(String[] args) {
		try {
			Ex_21_Relationship_Comment_Replies_Examples ex = new Ex_21_Relationship_Comment_Replies_Examples();
			ex.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/* To run this example
	 set DocId, RelationshipId and CommentId to your existing docId, relationshipId and
	 conversationId of relationship's comments */
	public void execute() throws Exception {
		String docId = "2f6d7b86-4a23-46c0-a20a-6fb98fef4c57";
		
		String relationshipId = "link-a881ad2e-93f5-4e7f-b3d0-cf404cbc3ea0";
			
		String commentId = "9a2560c5-5d7b-4e32-b2a2-5e6d07d6ede6";
			
		listRelationshipCommentReplies(docId, relationshipId, commentId);
	}

	private void listRelationshipCommentReplies(String docId, String relationshipId, String commentId) throws Exception {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		)
		{	
			ReplySearchCriteria replySearch = new ReplySearchCriteria().docId(docId)
					.relationshipId(relationshipId)
					.commentId(commentId).limit(5).page(1);					

			for (Iterator<Reply> replyIter = gClient.getRelationshipCommentReplies(replySearch); replyIter.hasNext();) {
				System.out.println(replyIter.next());
			}
		}
	}

}

