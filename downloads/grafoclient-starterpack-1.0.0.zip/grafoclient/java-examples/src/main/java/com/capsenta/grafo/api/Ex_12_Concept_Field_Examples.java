package com.capsenta.grafo.api;

import java.io.IOException;
import java.util.List;

import com.capsenta.grafo.GrafoClient;
import com.capsenta.grafo.entity.GenericGrafoResponse;
import com.capsenta.grafo.entity.ekg.Concept;
import com.capsenta.grafo.entity.ekg.Field;
import com.capsenta.grafo.entity.resource.Document;

public class Ex_12_Concept_Field_Examples {
	
	private Document document;
	
	private Concept concept;
	
	private List<Field> fieldList;
	
	
	public static void main(String[] args) {
		try {
			Ex_12_Concept_Field_Examples ex = new Ex_12_Concept_Field_Examples();
			ex.execute();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void execute() throws Exception {
		System.out.println("Creating Document and Adding Concepts To It");
		createDocumentAndAddConcept();
		
		System.out.println("Add Fields to Concept");
		addFieldsToConcepts();
		
		System.out.println("List Fields in a Concept");
		listFieldsInConcept();
		
		System.out.println("Get Concept Field By Id");
		getConceptFieldById();
		
		System.out.println("Update Concept Field");
		updateConceptField();
		
		System.out.println("Delete Concept Field");
		deleteConceptField();
		
		System.out.println("Delete Document");
		deleteDocument();
	}
	
	private void createDocumentAndAddConcept() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			System.out.println("************** Creating Document and concept***************** ");
			Document doc = new Document();
			doc.setTitle("Concept Field crud ops");
			document = gClient.createDocument(doc);
			
			Concept conceptForAdd1 = new Concept("Test1");
			concept = gClient.createConcept(document.getId(), conceptForAdd1);
			System.out.println(concept);
		}
	}
	
	private void addFieldsToConcepts() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			System.out.println("************** Adding Field to concept***************** ");
			Field field1 = new Field("field1"); field1.setText("text1");
			gClient.addConceptField(document.getId(), concept.getId(), field1);
			
			Field field2 = new Field("field2"); field2.setText("text2");
			gClient.addConceptField(document.getId(), concept.getId(), field2);
		}
	}
	
	private void listFieldsInConcept() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			System.out.println("************** Listing Fields in concept***************** ");
			fieldList = gClient.getConceptFields(document.getId(), concept.getId());
			System.out.println("Fields in "+concept.getId()+" are "+fieldList);
		}
	}
	
	private void getConceptFieldById() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			System.out.println("************** Fetching Field by id in concept***************** ");
			Field fieldFetched = gClient.getConceptField(document.getId(), concept.getId(), fieldList.get(1).getId());
			System.out.println("Field fetched from "+concept.getId()+" is "+fieldFetched);
		}
	}
	
	private void updateConceptField() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			System.out.println("************** Updating Field in concept***************** ");
			Field fieldToUpdate = gClient.getConceptField(document.getId(), concept.getId(), fieldList.get(0).getId());			
			fieldToUpdate.setTitle("updatedField1");
			fieldToUpdate.setText("updatedText1");
			Concept conceptFieldToUpdate = gClient.updateConceptField(document.getId(), concept.getId(), fieldToUpdate);
			System.out.println("Updated Concept Field: " + conceptFieldToUpdate);
		}
	}
	
	private void deleteConceptField() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			System.out.println("************** Deleting Field in concept***************** ");
			GenericGrafoResponse response = gClient.deleteConceptField(document.getId(), concept.getId(), fieldList.get(1).getId());
			System.out.println(response);
		}
	}
	
	private void deleteDocument() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			gClient.deleteDocument(document.getId());
		}
	}
}
