package com.capsenta.grafo.api;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

import com.capsenta.grafo.GrafoClient;
import com.capsenta.grafo.entity.GenericGrafoResponse;
import com.capsenta.grafo.entity.ekg.Color;
import com.capsenta.grafo.entity.ekg.Concept;
import com.capsenta.grafo.entity.resource.Document;

public class Ex_07_Concept_Examples 
{
	public static void main(String[] args) {
		try {
			Ex_07_Concept_Examples ex = new Ex_07_Concept_Examples();
			ex.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void execute() throws Exception {
		UUID docId = createDocument();
		
		Concept newConcept = createConcept(docId);
		System.out.println(newConcept);
		
		Concept updatedConcept = updateConcept(docId, newConcept);
		System.out.println(updatedConcept);
		
		List<Concept> listConcept = listAllConcepts(docId);
		listConcept.forEach(concept -> System.out.println(concept));
		
		Concept fetchConcept = fetchConceptById(docId, newConcept.getId());
		System.out.println(fetchConcept);
		
		deleteConcept(docId, newConcept.getId());
		
		deleteDocument(docId);
	}
	
	private UUID createDocument() throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		)
		{	
			System.out.println("************** Creating Document ***************** ");
			Document newDoc = new Document();
			newDoc.setTitle("My Test Doc " + System.currentTimeMillis());
			Document createdDoc = gClient.createDocument(newDoc);
			return createdDoc.getId();
		}
		
	}
	
	private Concept createConcept(UUID docId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			System.out.println("************** Creating Concept ***************** ");
			Concept concept = new Concept("MyConcept_01");
			concept.setDescription("Sample description");
			Concept newConcept = gClient.createConcept(docId, concept);
			return newConcept;
		}
		
	}
	
	private Concept updateConcept(UUID docId, Concept concept) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			System.out.println("************** Updating Concept ***************** ");
			concept.setLabel("UpdateConcept");
			concept.setColor(Color.CORAL_RED);
			Concept updatedConcept = gClient.updateConcept(docId, concept);
			return updatedConcept;
		}
		
	}
	
	private List<Concept> listAllConcepts(UUID docId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			//Creating 2 more concepts to demonstrate list concepts
			Concept concept1 = new Concept("MyConcept_02");
			Concept concept2 = new Concept("MyConcept_03");
			gClient.createConcept(docId, concept1);
			gClient.createConcept(docId, concept2);
			
			System.out.println("************** Listing all Concepts in the Document ***************** ");
			List<Concept> conceptList = gClient.getAllConcepts(docId);
			return conceptList;
		}
		
	}
	
	private Concept fetchConceptById(UUID docId, String conceptId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			System.out.println("************** Fetching Concept ***************** ");
			Concept fetchedConcept = gClient.getConcept(docId, conceptId);
			return fetchedConcept;
		}
		
	}
	
	private void deleteConcept(UUID docId, String conceptId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			System.out.println("************** Deleting Concept ***************** ");
			GenericGrafoResponse resp = gClient.deleteConcept(docId, conceptId);
			System.out.println(resp);
		}
	}
	

	private void deleteDocument(UUID docId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{
			System.out.println("************** Deleting Document ***************** ");
			gClient.deleteDocument(docId);
		}

	}


}

