package com.capsenta.grafo.api;

import java.time.LocalDateTime;
import java.util.Iterator;

import com.capsenta.grafo.GrafoClient;
import com.capsenta.grafo.entity.comment.Reply;
import com.capsenta.grafo.entity.comment.ReplySearchCriteria;

public class Ex_17_Concept_Comment_Replies_Examples {
	
	public static void main(String[] args) {
		try {
			Ex_17_Concept_Comment_Replies_Examples ex = new Ex_17_Concept_Comment_Replies_Examples();
			ex.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/* To run this example
	 set DocId, ConceptId and CommentId to your existing docId, conceptId and conversationId
	 of concept's comments */
	public void execute() throws Exception {
		String docId = "2f6d7b86-4a23-46c0-a20a-6fb98fef4c57";
		
		String conceptId = "node-f0850644-0f0e-4f7d-9aaf-eeb19413d934";
		
		String commentId = "0adacbb3-8fc8-439b-a22c-cbb5fb763282";
		
		System.out.println("*************Listing Concept Comment Replies");
		listConceptCommentReplies(docId, conceptId, commentId);
	}
	
	private void listConceptCommentReplies(String docId, String conceptId, String commentId) throws Exception {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		)
		{
			ReplySearchCriteria replySearch = new ReplySearchCriteria().docId(docId)
													.conceptId(conceptId)
													.commentId(commentId).limit(5).page(1)
													.createdOnOrBefore(LocalDateTime.now());
					
			for (Iterator<Reply> replyIter = gClient.getConceptCommentReplies(replySearch); replyIter.hasNext();) {
				System.out.println(replyIter.next());
			}
		}
	}
}
