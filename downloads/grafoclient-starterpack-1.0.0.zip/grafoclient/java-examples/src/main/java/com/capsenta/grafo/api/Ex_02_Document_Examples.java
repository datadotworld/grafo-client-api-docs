package com.capsenta.grafo.api;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Iterator;

import com.capsenta.grafo.GrafoClient;
import com.capsenta.grafo.entity.resource.Document;
import com.capsenta.grafo.entity.resource.Folder;
import com.capsenta.grafo.entity.resource.ResourceSearchCriteria;

public class Ex_02_Document_Examples {

	private Folder parentFolder;
	
	private Document documentWithoutParent1;
	
	private Document documentWithoutParent2;
	
	private Document documentWithoutParent3;
	
	private Document childDocument1;
	
	private Document childDocument2;
	
	public static void main(String[] args) {
		try {
			Ex_02_Document_Examples ex = new Ex_02_Document_Examples();
			ex.execute();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void execute() throws Exception {
		System.out.println("Create Documents without Parent Folder");
		createDocumentsWithoutParent();
		
		System.out.println("Create Documents with Parent Folder");
		createDocumentsWithParentFolder();
		
		System.out.println("List Documents without Parent");
		listDocumentsAtTopLevel();
		
		System.out.println("List Documents with Parent");
		listDocumentsWithParentFolder();
		
		System.out.println("Get Document By Id");
		getDocumentById();
		
		System.out.println("Update Document");
		updateDocument();
		
		System.out.println("Delete Documents");
		deleteDocuments();
	}
	
	private void createDocumentsWithoutParent() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			Document document1 = new Document(); document1.setTitle("DocWithoutParent 1");
			documentWithoutParent1 = gClient.createDocument(document1);
			
			Document document2 = new Document(); 
			document2.setTitle("DocWithoutParent 2"); 
			document2.setIri("DocWithoutParentIri");
			document2.setIriPrefix("DocWithoutParent");
			document2.setDescription("Doc Description");
			documentWithoutParent2 = gClient.createDocument(document2);
			
			Document document3 = new Document(); document3.setTitle("DocWithoutParent 3");
			documentWithoutParent3 = gClient.createDocument(document3);
		}
	}
	
	private void createDocumentsWithParentFolder() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			Folder folder1 = new Folder(); folder1.setTitle("Parent Folder");
			parentFolder = gClient.createFolder(folder1);
			
			Document document4 = new Document(); document4.setTitle("Child Doc 1"); document4.setParent(parentFolder.getId());
			childDocument1 = gClient.createDocument(document4);
			
			Document document5 = new Document(); 
			document5.setTitle("Child Doc 2"); 
			document5.setIri("DocWithoutParentIri");
			document5.setDescription("Doc Description");
			document5.setParent(parentFolder.getId());
			childDocument2 = gClient.createDocument(document5);
			
		}
	}
	
	private void listDocumentsAtTopLevel() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			ResourceSearchCriteria docSearchCrit = new ResourceSearchCriteria().limit(2).page(1).deleted(false).createdOn(LocalDate.now());
			for (Iterator<Document> docIter = gClient.getDocuments(docSearchCrit); docIter.hasNext();) {
				System.out.println(docIter.next());
			}
		}
	}
	
	private void listDocumentsWithParentFolder() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			ResourceSearchCriteria docSearchCrit = new ResourceSearchCriteria().limit(5).deleted(false).parent(parentFolder.getId()).createdOn(LocalDate.now());
			for (Iterator<Document> docIter = gClient.getDocuments(docSearchCrit); docIter.hasNext();) {
				System.out.println(docIter.next());
			}
		}
	}
	
	private void getDocumentById() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			Document doc = gClient.getDocument(childDocument1.getId());
			System.out.println("Document fetched: " + doc);
		}
	}
	
	private void updateDocument() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			Document docToUpdate = gClient.getDocument(documentWithoutParent2.getId());
			docToUpdate.setTitle("updatedTitle");
			docToUpdate.setIri("updatedIri");
			docToUpdate.setDescription("update Description");
			Document updatedDoc = gClient.updateDocument(docToUpdate);
			System.out.println("Document Updated: " + updatedDoc);
		}
	}
	
	private void deleteDocuments() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			gClient.deleteDocument(documentWithoutParent1.getId());
			gClient.deleteDocument(documentWithoutParent2.getId());
			gClient.deleteDocument(documentWithoutParent3.getId());
			//delete parent folder will delete child documents too
			gClient.deleteFolder(parentFolder.getId());
			System.out.println("Documents deleted");
		}
	}

}
