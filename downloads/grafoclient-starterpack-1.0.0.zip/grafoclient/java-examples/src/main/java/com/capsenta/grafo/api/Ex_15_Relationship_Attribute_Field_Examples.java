package com.capsenta.grafo.api;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.capsenta.grafo.GrafoClient;
import com.capsenta.grafo.entity.GenericGrafoResponse;
import com.capsenta.grafo.entity.ekg.Attribute;
import com.capsenta.grafo.entity.ekg.AttributeGroup;
import com.capsenta.grafo.entity.ekg.Concept;
import com.capsenta.grafo.entity.ekg.Field;
import com.capsenta.grafo.entity.ekg.Relationship;
import com.capsenta.grafo.entity.ekg.RelationshipType;
import com.capsenta.grafo.entity.resource.Document;

public class Ex_15_Relationship_Attribute_Field_Examples {
	
	private Document document;
	
	private Relationship relationship;
	
	private Attribute attr;
	
	private List<Field> fieldList;
	
	
	public static void main(String[] args) {
		try {
			Ex_15_Relationship_Attribute_Field_Examples ex = new Ex_15_Relationship_Attribute_Field_Examples();
			ex.execute();	
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void execute() throws Exception {
		System.out.println("Creating Document, Adding Relationship and attributes to it");
		createDocumentAndAddRelationshipAndAttribute();
		
		System.out.println("Add Fields to Relationship Attribute");
		addFieldsToRelationshipAttribute();
		
		System.out.println("List Fields in a Relationship Attribute");
		listFieldsInRelationshipAttribute();
		
		System.out.println("Get Relationship Attribute Field By Id");
		getRelationhipAttributeFieldById();
		
		System.out.println("Update Relationship Attribute Field");
		updateRelationshipAttributeField();
		
		System.out.println("Delete Relationship Attribute Field");
		deleteRelationshipAttributeField();
		
		System.out.println("Delete Document");
		deleteDocument();
	}
	
	private void createDocumentAndAddRelationshipAndAttribute() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			
			//Create Document
			Document doc = new Document();
			doc.setTitle("Concept Field crud ops");
			document = gClient.createDocument(doc);
			
			//Creating 2 concepts
			List<Concept> conceptList = new ArrayList<>();
			for(int i=0; i<2; i++) {
				Concept conceptForAdd = new Concept("Test " + i);
				Concept concept = gClient.createConcept(document.getId(), conceptForAdd);
				conceptList.add(concept);
			}
			
			//Create One Relationship
			Relationship relationship1 = new Relationship(conceptList.get(0), conceptList.get(1), "first link", RelationshipType.PEER);
			relationship = gClient.createRelationship(document.getId(), relationship1);
			
			//Add Relationship Attribute
			Attribute attr1 = new Attribute("Attr1");
			AttributeGroup attrGrp = gClient.addRelationshipAttribute(document.getId(), relationship.getId(), attr1);
			
			attr = attrGrp.getAttributes().get(0);
		}
	}
	
	private void addFieldsToRelationshipAttribute() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			
			
			Field field1 = new Field("field1"); field1.setText("text1");
			gClient.addRelationshipAttributeField(document.getId(), relationship.getId(), attr.getId(), field1);
			
			Field field2 = new Field("field2"); field2.setText("text2");
			gClient.addRelationshipAttributeField(document.getId(), relationship.getId(), attr.getId(), field2);
		}
	}
	
	private void listFieldsInRelationshipAttribute() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			fieldList = gClient.getRelationshipAttributeFields(document.getId(), relationship.getId(), attr.getId());
			System.out.println("Fields in "+relationship.getId()+" with attribute " + attr.getId() + " are " +fieldList);
		}
	}
	
	private void getRelationhipAttributeFieldById() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			Field fieldFetched = gClient.getRelationshipAttributeField(document.getId(), relationship.getId(), attr.getId(), fieldList.get(1).getId());
			System.out.println("Created Concept Attribute: " + fieldFetched);
		}
	}
	
	private void updateRelationshipAttributeField() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			Field fieldToUpdate = gClient.getRelationshipAttributeField(document.getId(), relationship.getId(), attr.getId(), fieldList.get(0).getId());			
			fieldToUpdate.setTitle("updatedField1");
			fieldToUpdate.setText("updatedText1");
			AttributeGroup attrGroup = gClient.updateRelationshipAttributeField(document.getId(), relationship.getId(), attr.getId(), fieldToUpdate);
			System.out.println("Updated Concept Attribute: " + attrGroup.getAttributes().get(0));
		}
	}
	
	private void deleteRelationshipAttributeField() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			GenericGrafoResponse response = gClient.deleteRelationshipAttributeField(document.getId(), relationship.getId(),  attr.getId(),  fieldList.get(1).getId());
			System.out.println(response);
		}
	}
	
	private void deleteDocument() throws IOException {
		try (GrafoClient gClient = new GrafoClient();) {
			gClient.deleteDocument(document.getId());
		}
	}
}
