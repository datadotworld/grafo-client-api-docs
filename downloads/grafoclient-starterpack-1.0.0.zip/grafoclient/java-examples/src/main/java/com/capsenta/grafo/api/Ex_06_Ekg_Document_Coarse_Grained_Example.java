package com.capsenta.grafo.api;

import java.io.IOException;
import java.util.UUID;

import com.capsenta.grafo.GrafoClient;
import com.capsenta.grafo.entity.ekg.Attribute;
import com.capsenta.grafo.entity.ekg.CardinalityType;
import com.capsenta.grafo.entity.ekg.Color;
import com.capsenta.grafo.entity.ekg.Concept;
import com.capsenta.grafo.entity.ekg.EkgDocument;
import com.capsenta.grafo.entity.ekg.Field;
import com.capsenta.grafo.entity.ekg.Relationship;
import com.capsenta.grafo.entity.ekg.RelationshipType;

public class Ex_06_Ekg_Document_Coarse_Grained_Example 
{
	public static void main(String[] args) {
		try {
			Ex_06_Ekg_Document_Coarse_Grained_Example ex = new Ex_06_Ekg_Document_Coarse_Grained_Example();
			ex.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void execute() throws Exception {
		EkgDocument createdEkgDoc = createEkgDocument();
		System.out.println(createdEkgDoc);
		
		EkgDocument fetchedEkgDoc = fetchEkgDocument(createdEkgDoc.getId());
		System.out.println(fetchedEkgDoc);
		
		EkgDocument updatedEkgDoc = updateEkgDocument(fetchedEkgDoc);
		System.out.println(updatedEkgDoc);
		
		deleteEkgDocument(createdEkgDoc.getId());
	}

	private EkgDocument createEkgDocument() throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		)
		{	 
			EkgDocument ekgDoc = new EkgDocument();
			ekgDoc.setTitle("My Test Doc " + System.currentTimeMillis());
			Concept c1 = new Concept("A");
			c1.setPositionX(200);
			c1.setPositionY(300);
			c1.addField(new Field("FieldA1"));
			ekgDoc.addNewConcept(c1);

			Concept c2 = new Concept("B");
			Field field1 = new Field("FieldB1");
			field1.setText("ValueB1");
			c2.addField(field1);
			Attribute attr1 = new Attribute("AttributeTest1");
			Attribute attr2 = new Attribute("AttributeTest2");
			c2.addAttribute(attr1);
			c2.addAttribute(attr2);
			Field attrField1 = new Field("FieldBAttr1");
			Field attrField2 = new Field("FieldBAttr2");
			attrField2.setText("ValueB2");
			attr2.addField(attrField1);
			attr2.addField(attrField2);
			ekgDoc.addNewConcept(c2);

			Relationship r1 = new Relationship(c1, c2, "peerlink", RelationshipType.PEER);
			r1.setCardinality(Integer.toString(100));
			r1.setCardinalityType(CardinalityType.EXACT);
			ekgDoc.addNewRelationship(r1);

			Relationship r2 = new Relationship(c1, "selflink");
			ekgDoc.addNewRelationship(r2);

			EkgDocument ekgDocAdded = gClient.addEkgDocument(ekgDoc);
			return ekgDocAdded;
		}
		
	}
	
	private EkgDocument fetchEkgDocument(String docIdStr) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			UUID docId = UUID.fromString(docIdStr);
			EkgDocument ekgDoc = gClient.getEkgDocument(docId);
			return ekgDoc;
		}
		
	}
	
	private EkgDocument updateEkgDocument(EkgDocument ekgDoc) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			ekgDoc.setTitle("Updated Document");
			Concept conceptForUpdate = ekgDoc.getConceptByLabel("A");
			Field field1 = new Field("Test2");
			field1.setText("Value2");
			conceptForUpdate.addField(field1);
			conceptForUpdate.setIri("www.abc.com/schema/ModifiedIritest1");
			conceptForUpdate.setColor(Color.LIGHT_GREY);
			EkgDocument ekgDocAdded = gClient.updateEkgDocument(ekgDoc);
			return ekgDocAdded;
		}
		
	}
	
	private void deleteEkgDocument(String docIdStr) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{
			System.out.println("Deleting Document ..... ");
			gClient.deleteEkgDocument(UUID.fromString(docIdStr));
		}

	}


}

