package com.capsenta.grafo.api;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.capsenta.grafo.GrafoClient;
import com.capsenta.grafo.entity.GenericGrafoResponse;
import com.capsenta.grafo.entity.ekg.Concept;
import com.capsenta.grafo.entity.ekg.Relationship;
import com.capsenta.grafo.entity.ekg.RelationshipType;
import com.capsenta.grafo.entity.resource.Document;

public class Ex_11_Specialization_Examples 
{
	public static void main(String[] args) {
		try {
			Ex_11_Specialization_Examples ex = new Ex_11_Specialization_Examples();
			ex.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void execute() throws Exception {
		UUID docId = createDocument();
		
		List<Concept> conceptList = createConcepts(docId);
		
		Relationship newRelationship = addSpecialization(docId, conceptList);
		System.out.println(newRelationship);
		
		List<Relationship> listSpecializations = listAllSpecializations(docId);
		listSpecializations.forEach(spclzn -> System.out.println(spclzn));
		
		Relationship fetchedSpclzn = fetchSpecializationById(docId, newRelationship.getId());
		System.out.println(fetchedSpclzn);
		
		deleteSpecialization(docId, newRelationship.getId());
		
		deleteDocument(docId);
	}
	
	private UUID createDocument() throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		)
		{	
			System.out.println("************** Creating Document ***************** ");
			Document newDoc = new Document();
			newDoc.setTitle("My Test Doc " + System.currentTimeMillis());
			Document createdDoc = gClient.createDocument(newDoc);
			return createdDoc.getId();
		}
		
	}
	
	private List<Concept> createConcepts(UUID docId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			List<Concept> conceptList = new ArrayList<>();
			System.out.println("************** Creating Concepts ***************** ");
			for(int i=0; i<3; i++) {
				Concept concept = new Concept("Test Concept " + i);
				Concept newConcept = gClient.createConcept(docId, concept);
				conceptList.add(newConcept);
			}
			return conceptList;
		}
	}
	
	private Relationship addSpecialization(UUID docId, List<Concept> conceptList) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			System.out.println("************** Adding Specializations ***************** ");
			Relationship specialization1 = new Relationship(conceptList.get(0), conceptList.get(1), "", RelationshipType.SPECIALIZATION);
			Relationship newRel = gClient.createSpecialization(docId, specialization1);
			
			Relationship specialization2 = new Relationship(conceptList.get(0), conceptList.get(2), "", RelationshipType.SPECIALIZATION);
			gClient.createRelationship(docId, specialization2);
			
			return newRel;
		}
		
	}
	
	private List<Relationship> listAllSpecializations(UUID docId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{			
			System.out.println("************** Listing all Specialization in the Document ***************** ");
			List<Relationship> relList = gClient.getAllSpecializations(docId);
			return relList;
		}
		
	}
	
	private Relationship fetchSpecializationById(UUID docId, String relId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			System.out.println("************** Fetching Specialization ***************** ");
			Relationship fetchedRel = gClient.getSpecialization(docId, relId);
			return fetchedRel;
		}
		
	}
	
	private void deleteSpecialization(UUID docId, String relId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			System.out.println("************** Deleting Specialization ***************** ");
			GenericGrafoResponse resp = gClient.deleteSpecialization(docId, relId);
			System.out.println(resp);
		}
	}
	

	private void deleteDocument(UUID docId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{
			System.out.println("************** Deleting Document ***************** ");
			gClient.deleteDocument(docId);
		}

	}


}

