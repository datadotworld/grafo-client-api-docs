package com.capsenta.grafo.api;

import java.util.Iterator;

import com.capsenta.grafo.GrafoClient;
import com.capsenta.grafo.entity.comment.Comment;
import com.capsenta.grafo.entity.comment.CommentSearchCriteria;

public class Ex_18_Concept_Attribute_Comments_Examples {

	public static void main(String[] args) {
		try {
			Ex_18_Concept_Attribute_Comments_Examples ex = new Ex_18_Concept_Attribute_Comments_Examples();
			ex.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/* To run this example
	 set DocId, ConceptId and attributeId to your existing docId, conceptId and attributeId
	 having comments */
	public void execute() throws Exception {
		String docId = "2f6d7b86-4a23-46c0-a20a-6fb98fef4c57";
		
		String conceptId = "node-f0850644-0f0e-4f7d-9aaf-eeb19413d934";
		
		String conceptAttributeId = "attr-f0f0bf84-a393-4964-922b-19d5c057f7b2";
		
		System.out.println("*************Listing Concept Attribute Comments");
		listConceptAttributeComments(docId, conceptId, conceptAttributeId);
	}
	
	private void listConceptAttributeComments(String docId, String conceptId, String conceptAttributeId) throws Exception {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		)
		{	
			CommentSearchCriteria commentSearchCrit = new CommentSearchCriteria().docId(docId)
															.conceptId(conceptId)
															.attributeId(conceptAttributeId).limit(5)
															.page(1);
			for (Iterator<Comment> commentIter = gClient.getConceptAttributeComments(commentSearchCrit); commentIter.hasNext();) {
				System.out.println(commentIter.next());
			}
		}
	}
}
