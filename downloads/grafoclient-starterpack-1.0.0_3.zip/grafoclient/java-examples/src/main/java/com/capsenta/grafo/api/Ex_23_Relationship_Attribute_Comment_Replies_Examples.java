package com.capsenta.grafo.api;

import java.util.Iterator;

import com.capsenta.grafo.GrafoClient;
import com.capsenta.grafo.entity.comment.Reply;
import com.capsenta.grafo.entity.comment.ReplySearchCriteria;

public class Ex_23_Relationship_Attribute_Comment_Replies_Examples 
{
	public static void main(String[] args) {
		try {
			Ex_23_Relationship_Attribute_Comment_Replies_Examples ex = new Ex_23_Relationship_Attribute_Comment_Replies_Examples();
			ex.execute();		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/* To run this example
	 set DocId, RelationshipId, attributeId and CommentId to your existing docId, relationshipId,
	 attributeId and conversationId of relationship attribute's comments */
	public void execute() throws Exception {
		String docId = "2f6d7b86-4a23-46c0-a20a-6fb98fef4c57";
		
		String relationshipId = "link-a881ad2e-93f5-4e7f-b3d0-cf404cbc3ea0";
		
		String attrId = "linkattr-999ad167-b246-4dde-8a81-3752d02fd0e0";
		
		String commentId = "137da9b8-2bfe-44ab-9896-50cd1303510e";
		
		listRelationshipAttrCommentReplies(docId, relationshipId, attrId, commentId);
	}

	private void listRelationshipAttrCommentReplies(String docId, String relationshipId, String attrId, String commentId) throws Exception {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		)
		{	
			ReplySearchCriteria replySearch = new ReplySearchCriteria().docId(docId)
					.relationshipId(relationshipId)
					.attributeId(attrId)
					.commentId(commentId).limit(5).page(1);
			
			for (Iterator<Reply> replyIter = gClient.getRelationshipAttributeCommentReplies(replySearch); replyIter.hasNext();) {
				System.out.println(replyIter.next());
			}
		}
	}

}

