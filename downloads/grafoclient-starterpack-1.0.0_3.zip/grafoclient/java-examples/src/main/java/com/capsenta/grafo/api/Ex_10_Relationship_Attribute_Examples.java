package com.capsenta.grafo.api;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.capsenta.grafo.GrafoClient;
import com.capsenta.grafo.entity.GenericGrafoResponse;
import com.capsenta.grafo.entity.ekg.Attribute;
import com.capsenta.grafo.entity.ekg.AttributeGroup;
import com.capsenta.grafo.entity.ekg.CardinalityType;
import com.capsenta.grafo.entity.ekg.Concept;
import com.capsenta.grafo.entity.ekg.Relationship;
import com.capsenta.grafo.entity.ekg.RelationshipType;
import com.capsenta.grafo.entity.resource.Document;

public class Ex_10_Relationship_Attribute_Examples 
{
	public static void main(String[] args) {
		try {
			Ex_10_Relationship_Attribute_Examples ex = new Ex_10_Relationship_Attribute_Examples();
			ex.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void execute() throws Exception {
		UUID docId = createDocument();
		
		List<Concept> conceptList = createConcepts(docId);
		
		Relationship newRelationship = addRelationship(docId, conceptList);
		System.out.println(newRelationship);
		
		Attribute newAttribute = addAttribute(docId, newRelationship.getId());
		System.out.println(newAttribute);
		
		Attribute updatedAttribute = updateAttribute(docId, newRelationship.getId(), newAttribute);
		System.out.println(updatedAttribute);
		
		List<Attribute> listAttributes = listAllRelationshipAttributes(docId, newRelationship.getId());
		listAttributes.forEach(attr -> System.out.println(attr));
		
		Attribute fetchedAttr = fetchAttributeById(docId, newRelationship.getId(), newAttribute.getId());
		System.out.println(fetchedAttr);
		
		deleteAttribute(docId, newRelationship.getId(), fetchedAttr.getId());
		
		deleteDocument(docId);
	}

	private UUID createDocument() throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		)
		{	
			System.out.println("************** Creating Document For Concept Attribute CRUD Demo ***************** ");
			Document newDoc = new Document();
			newDoc.setTitle("My Test Doc " + System.currentTimeMillis());
			Document createdDoc = gClient.createDocument(newDoc);
			return createdDoc.getId();
		}
		
	}
	
	private List<Concept> createConcepts(UUID docId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			List<Concept> conceptList = new ArrayList<>();
			System.out.println("************** Creating Concepts ***************** ");
			for(int i=0; i<2; i++) {
				Concept concept = new Concept("Test Concept " + i);
				Concept newConcept = gClient.createConcept(docId, concept);
				conceptList.add(newConcept);
			}
			return conceptList;
		}
	}
	
	private Relationship addRelationship(UUID docId, List<Concept> conceptList) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			System.out.println("************** Adding Relationship ***************** ");
			Relationship relationship1 = new Relationship(conceptList.get(0), conceptList.get(1), "first link", RelationshipType.PEER);
			Relationship newRel = gClient.createRelationship(docId, relationship1);			
			return newRel;
		}
		
	}
	
	private Attribute addAttribute(UUID docId, String relId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{
			System.out.println("************** Adding Attribute to Relationship ***************** ");
			Attribute attribute = new Attribute("Attribute1");
			AttributeGroup newAttrGroup = gClient.addRelationshipAttribute(docId, relId, attribute);
			System.out.println("New Attribute Group created: " + newAttrGroup);
			return newAttrGroup.getAttributes().get(0);
		}
	}
	
	private Attribute updateAttribute(UUID docId, String relId, Attribute attribute) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			System.out.println("************** Updating Attribute ***************** ");
			attribute.setLabel("Updated Attribute");
			attribute.setCardinalityType(CardinalityType.EXACT);
			attribute.setCardinality("100");
			AttributeGroup newAttrGroup = gClient.updateRelationshipAttribute(docId, relId, attribute);
			return newAttrGroup.getAttributes().get(0);
		}
		
	}
	
	private List<Attribute> listAllRelationshipAttributes(UUID docId, String relId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			//Creating 2 more attributes to demonstrate list attributes
			Attribute attribute2 = new Attribute("Attribute2");
			gClient.addRelationshipAttribute(docId, relId, attribute2);
			
			Attribute attribute3 = new Attribute("Attribute3");
			gClient.addRelationshipAttribute(docId, relId, attribute3);
			
			System.out.println("************** Listing all Attributes for the Realtionship ***************** ");
			List<Attribute> attrList = gClient.getAllRelationshipAttributes(docId, relId);
			return attrList;
		}
		
	}
	
	private Attribute fetchAttributeById(UUID docId, String relId, String attrId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			System.out.println("************** Fetching Attribute ***************** ");
			Attribute fetchedAttr = gClient.getRelationshipAttribute(docId, relId, attrId);
			return fetchedAttr;
		}
		
	}
	
	private void deleteAttribute(UUID docId, String relId, String attrId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{ 
			System.out.println("************** Deleting Attribute ***************** ");
			GenericGrafoResponse resp = gClient.deleteRelationshipAttribute(docId, relId, attrId);
			System.out.println(resp);
		}
	}
	

	private void deleteDocument(UUID docId) throws IOException {
		try 
		(
			GrafoClient gClient = new GrafoClient();
		) 
		{
			System.out.println("************** Deleting Document ***************** ");
			gClient.deleteDocument(docId);
		}

	}

}

