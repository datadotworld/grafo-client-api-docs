package com.capsenta.grafo.api;

import org.junit.Test;

public class Test_Examples {

	@Test
	public void execute_all_grafo_client_examples() throws Exception {
		Ex_99_All_In_One_Examples allExamples = new Ex_99_All_In_One_Examples();
		allExamples.executeAll();
	}

}
