'use strict';

var folderExample = require('./01_Folder_Examples');
var docExample = require('./02_Document_Examples');
var sharedAreaFolderExample =  require('./03_Shared_Area_Folder_Examples');
var docsSharedWithMeExample = require('./04_Documents_Shared_With_Me_Examples');
var mySharedDocsExample = require('./05_Document_Share_Examples');
var ekgDocCoarseGrainedExample = require('./06_EKG_Document_Coarse_Grained_Examples');
var conceptExample = require('./07_Concept_Examples');
var conceptAttrExample = require('./08_Concept_Attribute_Examples');
var relationshipExample = require('./09_Relationship_Examples');
var relationshipAttrExample = require('./10_Relationship_Attribute_Examples');
var specializationExample = require('./11_Specialization_Examples');
var conceptFieldExample = require('./12_Concept_Field_Examples');
var relationshipFieldExample = require('./13_Relationship_Field_Examples');
var conceptAttrFieldExample = require('./14_Concept_Attribute_Field_Examples');
var relationshipAttrFieldExample = require('./15_Relationship_Attribute_Field_Examples');

/* This does not contain comments and comment replies examples for concept, relationship and their
*  attributes as they are not reproducible*/
this.executeAll = async function() {
    await folderExample.execute();
	await docExample.execute();
    await sharedAreaFolderExample.execute();
    await docsSharedWithMeExample.execute();
    await mySharedDocsExample.execute();
    await ekgDocCoarseGrainedExample.execute();
    await conceptExample.execute();
    await conceptAttrExample.execute();
    await relationshipExample.execute();
    await relationshipAttrExample.execute();
    await specializationExample.execute();
    await conceptFieldExample.execute();
    await relationshipFieldExample.execute();
    await conceptAttrFieldExample.execute();
    await relationshipAttrFieldExample.execute();
};

exports.executeAll();

module.exports = {
    executeAll: this.executeAll
};