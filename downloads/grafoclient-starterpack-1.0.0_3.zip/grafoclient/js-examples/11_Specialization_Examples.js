'use strict';

var GrafoClient = require('grafo-client/lib/grafo_client');
var Document = require('grafo-client/lib/models/document');

var config = require('./conf/conf.js');

this.execute = async function() {
    console.log("Starting Grafo Client Relationship CRUD Example");
    var grafoClient = new GrafoClient();
    console.log("Authenticating to Grafo Server with the provided config : ");
    console.log(config);
    await grafoClient.init(config);
    console.log("Authenticated");

    var ekgDoc = await createEmptyEkgDoc(grafoClient);

    var conceptIdList = await createConcepts(grafoClient, ekgDoc);

    await doSpecialisationCrudOps(grafoClient, ekgDoc, conceptIdList);

    await deleteEkgDocument(grafoClient, ekgDoc.id);

    console.log("closing connection");
    await grafoClient.close();
};

var createEmptyEkgDoc = async function(grafoClient) {
    var d = new Date();
    var document1 = new Document(); document1.setTitle('TestDoc_' + d.getTime());
    console.log("Creating Document with name " +  document1.getTitle() + " in default location ... ");
    var docDetails =  await grafoClient.createDocument(document1);
    var ekgDoc = await grafoClient.createEkgDocument(docDetails);
    console.log("Created Empty EKG Document with Id " + ekgDoc.id);
    return ekgDoc;
};

var createConcepts = async function(grafoClient, ekgDoc){
    var conceptIdList = [];

    for(var i=0; i< 3; i++){
        var concept = await ekgDoc.addConcept("Test " + i);
        conceptIdList.push(concept.getId());
    }
    return conceptIdList;
};

var doSpecialisationCrudOps = async function(grafoClient, ekgDoc, conceptIdList) {
    /*
        ADDING SPECIALIZATIONS
        Parameters to addRelationship method in order are listed below
        label(null or ""), fromConceptId, toConceptId, specialization(true), description,
        color, fields, cardinalityType, cardinality, positionX, positionY, iri, id
     */
    console.log("Adding specialization to doc ...");
    var rel1 = await ekgDoc.addRelationship(null, conceptIdList[0], conceptIdList[1], true);
    var rel2 = await ekgDoc.addRelationship(null, conceptIdList[0], conceptIdList[2], true);
    console.log("Two specializations added");

    /*
      LISTING ALL SPECIALIZATIONS IN THE DOCUMENT
   */
    console.log("Listing all the specializations in the document........");
    var specializationList = await ekgDoc.getSpecializations();
    console.log(specializationList);

    /*
        FETCHING ONE SPECIALIZATION
     */

    console.log("Fetching specialization...");
    var fetchedSpcl = ekgDoc.getSpecialization(rel2.getId());
    console.log(fetchedSpcl.toObject());


    /*
        DELETING SPECIALIZATION
     */
    console.log("Deleting specialization ....");
    await ekgDoc.deleteRelationship(rel1.getId());
    console.log("Relationship Deleted");
};


var deleteEkgDocument = async function(grafoClient, ekgDocId) {
    console.log("Deleting Document....");
    await grafoClient.deleteEkgDocument(ekgDocId);
};

module.exports = {
    execute: this.execute
};