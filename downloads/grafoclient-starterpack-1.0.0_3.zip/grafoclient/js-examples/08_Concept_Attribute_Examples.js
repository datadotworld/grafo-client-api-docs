'use strict';

var GrafoClient = require('grafo-client/lib/grafo_client');
var Document = require('grafo-client/lib/models/document');
var DataTypes = require('grafo-client/lib/models/datatypes');

var config = require('./conf/conf.js');

this.execute = async function() {
    console.log("Starting Grafo Client Concept Attribute CRUD Example");
    var grafoClient = new GrafoClient();
    console.log("Authenticating to Grafo Server with the provided config");
    await grafoClient.init(config);
    console.log("Authenticated");

    var ekgDoc = await createEmptyEkgDoc(grafoClient);

    var conceptId = await createConcept(grafoClient, ekgDoc);

    await doConceptAttributeCrudOps(grafoClient, ekgDoc, conceptId);

    await deleteEkgDocument(grafoClient, ekgDoc.id);

    console.log("closing connection");
    await grafoClient.close();
};

var createEmptyEkgDoc = async function(grafoClient) {
    var d = new Date();
    var document1 = new Document(); document1.setTitle('TestDoc_' + d.getTime());
    console.log("Creating Document with name " +  document1.getTitle() + " in default location ... ");
    var docDetails =  await grafoClient.createDocument(document1);
    var ekgDoc = await grafoClient.createEkgDocument(docDetails);
    console.log("Created Empty EKG Document with Id " + ekgDoc.id);
    return ekgDoc;
};

var createConcept = async function(grafoClient, ekgDoc){
    var conceptCreated01 = await ekgDoc.addConcept("TestA");
    return conceptCreated01.getId();
}

var doConceptAttributeCrudOps = async function(grafoClient, ekgDoc, conceptId) {
    /*
        ADDING ATTRIBUTES TO CONCEPT
        Parameters to addAttributeToConcept method in order are listed below
        label, description, fields, xsdDataType, cardinalityType, cardinality, iri, id, conceptId
     */
    console.log("Adding attribute to concept ...");
    await ekgDoc.addAttributeToConcept("First Attribute", null, null, null,
        null, null, null, null, conceptId);
    await ekgDoc.addAttributeToConcept("Second Attribute", "This is the second attribute", null, null,
        null, null, null, null, conceptId);
    await ekgDoc.addAttributeToConcept("Third Attribute", null, [{"title":"Hello"}, {"text": "World"}],
        DataTypes.XsdDataType.DATETIME, null, null, null, null, conceptId);
    console.log("Three attributes added");

    /*
        LISTING ALL CONCEPT ATTRIBUTES
    */
    console.log("Listing all the attributes for the concept in the document........");
    var attributeList = await ekgDoc.getConceptAttributes(conceptId);
    console.log(attributeList);


    /*
        FETCHING ONE ATTRIBUTE
     */

    console.log("Fetching Attribute");
    var fetchedAttribute = await ekgDoc.getConceptAttribute(conceptId, attributeList[0].id);
    console.log(fetchedAttribute.toObject());


    /*
        UPDATING ATTRIBUTES TO CONCEPT
        Parameters to updateAttributeToConcept method in order are listed below
        label, description, fields, xsdDataType, cardinalityType, cardinality, iri, id, conceptId
     */
    console.log("Updating Attribute to concept ....");
    await ekgDoc.updateAttributeToConcept("Hello Label", "Updated Attribute",
        null, null, null, null, null, null, attributeList[1].id, conceptId);
    console.log("Updated......");

    /*
        DELETING ATTRIBUTE
     */
    console.log("Deleting Attribute ....");
    await ekgDoc.deleteConceptAttribute(conceptId, attributeList[2].id);
    console.log("Attribute Deleted");

};


var deleteEkgDocument = async function(grafoClient, ekgDocId) {
    console.log("Deleting Document....");
    await grafoClient.deleteEkgDocument(ekgDocId);
};

module.exports = {
  execute: this.execute
};