'use strict';

var GrafoClient = require('grafo-client/lib/grafo_client');
var Document = require('grafo-client/lib/models/document');

var config = require('./conf/conf.js');

this.execute = async function() {
    console.log("Starting Grafo Client EKG Document Coarse Grained Example");
    var grafoClient = new GrafoClient();
    console.log("Authenticating to Grafo Server with the provided config");
    await grafoClient.init(config);
    console.log("Authenticated");

    // Create EKG Document
    var ekgDoc = await createEkgDocWithoutElements(grafoClient);
    console.log(ekgDoc.toObject());

    //Add elements to the above created EKG Document
    //This will make use of fine-grained endpoints.
    await addElements(grafoClient, ekgDoc);

    // Get EKG Document
    var ekgDocFetched = await getEkgDocument(grafoClient, ekgDoc.id);
    console.log(ekgDocFetched.toObject());

    // Delete EKG Document
    await deleteEkgDocument(grafoClient, ekgDoc.id);

    console.log("closing connection");
    await grafoClient.close();
};

var createEkgDocWithoutElements = async function(grafoClient) {
    var d = new Date();
    var document1 = new Document(); document1.setTitle('TestDoc_' + d.getTime());
    console.log("Creating Document with name " +  document1.getTitle() + " in default location ... ");
    var docDetails =  await grafoClient.createDocument(document1);
    var ekgDoc = await grafoClient.createEkgDocument(docDetails);
    console.log("Created Empty EKG Document with Id " + ekgDoc.id);
    return ekgDoc;
};

var addElements = async function(grafoClient, ekgDoc) {
    //Refer to examples in concepts and relationships for fine-grained operations
    console.log("Adding elements to the document.........");
    var conceptCreated01 = await ekgDoc.addConcept("A", 200, 300, null, null, [{"title":"FieldA1"}]);
    var conceptCreated02 = await ekgDoc.addConcept("B", null, null, null, null, [{"title":"FieldB1", "text":"ValueB1"}]);

    var attrGroup1 = await ekgDoc.addAttributeToConcept("AttributeTest1", null, null, null,
        null, null, null, null, conceptCreated02.getId());
    var updatedattrGroup1 = await ekgDoc.addAttributeToConcept("AttributeTest2", null,
        [{"title":"FieldBAttr1"}, {"title":"FieldBAttr2", "text":"ValueB2"}], null, null,
        null, null, null, conceptCreated02.getId());

    var rel01 = await ekgDoc.addRelationship("peerlink", conceptCreated01.getId(), conceptCreated02.getId());
    var rel02 = await ekgDoc.addRelationship("selflink", conceptCreated01.getId(), conceptCreated01.getId());

    for (var i=0; i<20; i++){
        await ekgDoc.addRelationship("peerlink", conceptCreated01.getId(), conceptCreated02.getId());
    }
    console.log("Finished Adding Elements...")
};

var getEkgDocument = async function(grafoClient, docId) {
    console.log("Fetching Document " + docId + "....");
    var docDetails = await grafoClient.getDocument(docId);
    var ekgDoc = await grafoClient.getEkgDocument(docDetails);
    return ekgDoc;
};

var deleteEkgDocument = async function(grafoClient, ekgDocId) {
    console.log("Deleting Document....");
    await grafoClient.deleteEkgDocument(ekgDocId);
};

module.exports = {
    execute: this.execute
};