Grafo Client 1.0.0

To run java examples:
1. cd java-examples/conf
2. Make a copy of grafo-client-template.properties. Name the file as grafo-client.properties
3. Put the appropriate values of userid, password and token in that file
4. Run ./mvnw clean package (Windows: mvnw clean package). This will compile and package the examples
5. Run .mvnw exec:java -Dapp.configurationFile=conf/grafo-client.properties This will run the examples


To run js examples:
1. cd js-examples/conf
2. Make a copy of conf_template.js. Name the file as conf.js
3. Put the appropriate values of userid, password and token in that file
4. Run npm install
5. Run npm start 

You can also run individual js-examples with "node <example js file name>"

NOTE: it is quite possible that when you run the tests, you might encounter error messages due to high rate of requests. 
This can be overcome only by reducing the rate and number of requests.